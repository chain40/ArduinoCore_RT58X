/** @file bsp_console.h
 * @license
 * @description
 */

#ifndef __BSP_CONSOLE_H__
#define __BSP_CONSOLE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "bsp.h"


#define __cli_cmd_pool          __attribute__ ((used, section("cli_cmd_pool")))

int bsp_console_init(bsp_event_callback_t callback);
int bsp_console_stdin_str(char *pBuf, int length);
int bsp_console_stdout_string(char *str, int length);
int bsp_console_stdout_char(int ch);
int bsp_console_stdio_flush(void);

#ifdef __cplusplus
}
#endif

#endif
