/******************************************************************************
*
* @File			Ruci_Pci15p4MacCmd.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_Pci15p4MacCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_PCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: InitiateZigbee --------------------------------------------------------
const uint8_t Ruci_ElmtType_InitiateZigbee[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_InitiateZigbee[] = {
    1, 1, 1
};

// RUCI: Set15p4AddressFilter --------------------------------------------------
const uint8_t Ruci_ElmtType_Set15p4AddressFilter[] = {
    1, 1, 1, 1, 2, 4, 2, 1
};
const uint8_t Ruci_ElmtNum_Set15p4AddressFilter[] = {
    1, 1, 1, 1, 1, 2, 1, 1
};

// RUCI: Set15p4MacPib ---------------------------------------------------------
const uint8_t Ruci_ElmtType_Set15p4MacPib[] = {
    1, 1, 1, 4, 4, 1, 1, 4, 1, 1
};
const uint8_t Ruci_ElmtNum_Set15p4MacPib[] = {
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1
};

// RUCI: Set15p4AutoAck --------------------------------------------------------
const uint8_t Ruci_ElmtType_Set15p4AutoAck[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_Set15p4AutoAck[] = {
    1, 1, 1, 1
};

// RUCI: Set15p4PhyPib ---------------------------------------------------------
const uint8_t Ruci_ElmtType_Set15p4PhyPib[] = {
    1, 1, 1, 2, 1, 1, 2
};
const uint8_t Ruci_ElmtNum_Set15p4PhyPib[] = {
    1, 1, 1, 1, 1, 1, 1
};

// RUCI: Set15p4PendingBit -----------------------------------------------------
const uint8_t Ruci_ElmtType_Set15p4PendingBit[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_Set15p4PendingBit[] = {
    1, 1, 1, 1
};

#endif /* RUCI_ENABLE_PCI */
#endif /* RUCI_ENDIAN_INVERSE */
