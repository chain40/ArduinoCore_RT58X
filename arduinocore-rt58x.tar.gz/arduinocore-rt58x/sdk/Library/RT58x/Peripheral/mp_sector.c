/** @file
 *
 * @brief MP sector file.
 *
 */

/**
 * @defgroup MP_Sector Group
 * @{
 * @brief    MP_Sector group.
 */

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
#include <stdio.h>
#include <string.h>
#include "cm3_mcu.h"
#include "mp_sector.h"
#include "project_config.h"


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/

 
 /**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/


/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/
void MpCalDcdcInit(mp_cal_regulator_t *mp_cal_reg)
{
    uint8_t flag;
    uint8_t select;
    uint8_t target_vosel = 0;

    flag = mp_cal_reg->flag;
    select = mp_cal_reg->select;

    switch (select)
    {
        case 1:
            target_vosel = mp_cal_reg->target_vosel_1;
            break;

        case 2:
            target_vosel = mp_cal_reg->target_vosel_2;
            break;

        case 3:
            target_vosel = mp_cal_reg->target_vosel_3;
            break;

        default:
            flag = 0;
            break;
    }

    if ((flag == 1) || (flag == 2))
    {
        PMU->PMU_VOUT_SEL0.bit.DCDC_VOSEL_NM = target_vosel;
        PMU->PMU_VOUT_SEL0.bit.DCDC_VOSEL_SP = target_vosel;
        PMU->PMU_VOUT_SEL0.bit.DCDC_VOSEL_DS = target_vosel;
    }
}

void MpCalLldoInit(mp_cal_regulator_t *mp_cal_reg)
{
    uint8_t flag;
    uint8_t select;
    uint8_t target_vosel = 0;

    flag = mp_cal_reg->flag;
    select = mp_cal_reg->select;

    switch (select)
    {
        case 1:
            target_vosel = mp_cal_reg->target_vosel_1;
            break;

        case 2:
            target_vosel = mp_cal_reg->target_vosel_2;
            break;

        case 3:
            target_vosel = mp_cal_reg->target_vosel_3;
            break;

        default:
            flag = 0;
            break;
    }

    if ((flag == 1) || (flag == 2))
    {
        PMU->PMU_VOUT_SEL0.bit.LLDO_VOSEL_NM = target_vosel;
        PMU->PMU_VOUT_SEL0.bit.LLDO_VOSEL_SP = target_vosel;
        PMU->PMU_VOUT_SEL0.bit.LLDO_VOSEL_DS = target_vosel;
    }
}

void MpCalIoldoInit(mp_cal_regulator_t *mp_cal_reg)
{
    uint8_t flag;
    uint8_t select;
    uint8_t target_vosel = 0;

    flag = mp_cal_reg->flag;
    select = mp_cal_reg->select;

    switch (select)
    {
        case 1:
            target_vosel = mp_cal_reg->target_vosel_1;
            break;

        case 2:
            target_vosel = mp_cal_reg->target_vosel_2;
            break;

        case 3:
            target_vosel = mp_cal_reg->target_vosel_3;
            break;

        default:
            flag = 0;
            break;
    }

    if ((flag == 1) || (flag == 2))
    {
        PMU->PMU_VOUT_SEL2.bit.IOLDO_VOSEL_NM = target_vosel;
        PMU->PMU_VOUT_SEL2.bit.IOLDO_VOSEL_SP = target_vosel;
        PMU->PMU_VOUT_SEL2.bit.IOLDO_VOSEL_DS = target_vosel;
    }
}

void MpCalSldoInit(mp_cal_regulator_t *mp_cal_reg)
{
    uint8_t flag;
    uint8_t select;
    uint8_t target_vosel = 0;

    flag = mp_cal_reg->flag;
    select = mp_cal_reg->select;

    switch (select)
    {
        case 1:
            target_vosel = mp_cal_reg->target_vosel_1;
            break;

        case 2:
            target_vosel = mp_cal_reg->target_vosel_2;
            break;

        case 3:
            target_vosel = mp_cal_reg->target_vosel_3;
            break;

        default:
            flag = 0;
            break;
    }

    if ((flag == 1) || (flag == 2))
    {
        PMU->PMU_VOUT_SEL1.bit.SLDO_VOSEL_NM = target_vosel;
        PMU->PMU_VOUT_SEL1.bit.SLDO_VOSEL_SP = target_vosel;
        PMU->PMU_VOUT_SEL1.bit.SLDO_VOSEL_DS = target_vosel;
    }
}

void MpCalSioldoInit(mp_cal_regulator_t *mp_cal_reg)
{
    uint8_t flag;
    uint8_t select;
    uint8_t target_vosel = 0;

    flag = mp_cal_reg->flag;
    select = mp_cal_reg->select;

    switch (select)
    {
        case 1:
            target_vosel = mp_cal_reg->target_vosel_1;
            break;

        case 2:
            target_vosel = mp_cal_reg->target_vosel_2;
            break;

        case 3:
            target_vosel = mp_cal_reg->target_vosel_3;
            break;

        default:
            flag = 0;
            break;
    }

    if ((flag == 1) || (flag == 2))
    {
        PMU->PMU_VOUT_SEL2.bit.IOLDO_RET_VOSEL_NM = target_vosel;
        PMU->PMU_VOUT_SEL2.bit.IOLDO_RET_VOSEL_SP = target_vosel;
        PMU->PMU_VOUT_SEL2.bit.IOLDO_RET_VOSEL_DS = target_vosel;
    }
}

void MpCalPowerfailInit(mp_cal_regulator_t *mp_cal_reg)
{
    uint8_t flag;
    uint8_t select;
    uint8_t target_vosel = 0;

    flag = mp_cal_reg->flag;
    select = mp_cal_reg->select;

    switch (select)
    {
        case 1:
            target_vosel = mp_cal_reg->target_vosel_1;
            break;

        case 2:
            target_vosel = mp_cal_reg->target_vosel_2;
            break;

        case 3:
            target_vosel = mp_cal_reg->target_vosel_3;
            break;

        default:
            flag = 0;
            break;
    }

    if ((flag == 1) || (flag == 2))
    {
        PMU->PMU_COMP0.bit.AUX_COMP_VSEL = target_vosel;
    }
}

void MpCalCrystaltrimInit(mp_cal_xtal_trim_t *mp_cal_xtaltrim)
{
    uint8_t flag;
    uint16_t target_xo_trim;

    flag = mp_cal_xtaltrim->flag;
    target_xo_trim = mp_cal_xtaltrim->xo_trim;

    if ((flag == 1) || (flag == 2))
    {
        PMU->PMU_PM_SEL.bit.XOCAP_UPDATE_MODE = 1;
        PMU->PMU_XTAL.bit.CFG_XTAL_CAP_SEL = target_xo_trim;
    }
}

mp_sector_head_t * GetSpecValidMpId(uint32_t spec_mp_id);
mp_sector_head_t * GetNullMpId(void);

uint32_t MpCalRftrimWrite(uint32_t mp_id, mp_cal_rf_trim_t *mp_cal_rf)
{
    uint32_t i;
    uint32_t write_status = STATUS_SUCCESS;
    uint32_t write_addr;
    uint32_t write_cnt;
    uint8_t write_byte;
    uint8_t *pWriteByte;

    mp_sector_head_t *valid_rf_trim;
    valid_rf_trim =	GetSpecValidMpId(mp_id);


    pWriteByte = (uint8_t *)mp_cal_rf;

    //write_cnt = mp_cal_rf->head.mp_cnt;
    write_cnt = sizeof(mp_cal_rf_trim_t);
    write_addr = (uint32_t)GetNullMpId();

    if (write_addr == 0)
        return STATUS_ERROR;

    for (i = 0; i < write_cnt; i++)
    {
        write_byte = *pWriteByte;
        pWriteByte++;

        flash_write_byte((write_addr + i), write_byte);
        while(flash_check_busy());
    }

    write_addr = (uint32_t)&valid_rf_trim->mp_valid;
    flash_write_byte(write_addr, MP_INVALID);
    while(flash_check_busy());

    if (CACHE->CCR.bit.CACHE_EN)
    {			
        CACHE->CCR.bit.CACHE_EN = 0;
        CACHE->CCR.bit.CACHE_EN = 1;
    }

    return write_status;
}

uint32_t MpCalRftrimRead(uint32_t mp_id, uint32_t byte_cnt, uint8_t *mp_sec_data)
{
    uint32_t i;
    uint32_t read_status = STATUS_SUCCESS;
    uint8_t *pValidByte;
    uint8_t *pReadByte;

    mp_sector_head_t *valid_mp_sec;
    valid_mp_sec =	GetSpecValidMpId(mp_id);

    do
    {
        if (valid_mp_sec == NULL)
        {
            read_status = STATUS_INVALID_REQUEST;
            break;
        }

        pValidByte = (uint8_t *)valid_mp_sec;
        pReadByte = (uint8_t *)mp_sec_data;

        for (i = 0; i < byte_cnt; i++)
        {
            *pReadByte = *pValidByte;
            pValidByte++;
            pReadByte++;
        }

    } while(0);

    return read_status;
}
/*
mp_sector_head_t * GetFirstValidMpId(mp_sector_head_t *pMpHead)
{
//    uint32_t get_status = 0;
    uint32_t mp_next = 0;

    mp_sector_head_t *pSearchHead;

    pSearchHead = pMpHead;

    do
    {
        if (pSearchHead->mp_id == MP_ID_NULL)
        {
            pMpHead = NULL;
//            get_status = 0;
            break;
		    }

        if (pSearchHead->mp_valid == MP_VALID)
        {
            pMpHead = pSearchHead;
//            get_status = 1;
            break;
		    }

        mp_next = (uint32_t)pSearchHead;
        mp_next += pSearchHead->mp_cnt;
        pSearchHead = (mp_sector_head_t *)mp_next;
    } while (1);

//    return get_status;
    return pMpHead;
}

uint32_t GetNextValidMpId(mp_sector_head_t *pMpHead)
{
}
*/

mp_sector_head_t * GetNextMpId(mp_sector_head_t *pMpHead)
{
    uint32_t mp_next = 0;
    mp_sector_head_t *pNextHead = NULL;

    if ((pMpHead->mp_id != MP_ID_NULL) && (pMpHead->mp_cnt != 0))
    {
        mp_next = (uint32_t)pMpHead;
        mp_next += pMpHead->mp_cnt;
        pNextHead = (mp_sector_head_t *)mp_next;
    }

    return pNextHead;
}

mp_sector_head_t * GetFirstValidMpId(mp_sector_head_t *pMpHead)
{
    mp_sector_head_t *pValidHead = NULL;

    while ((pMpHead != NULL) && (pMpHead->mp_id != MP_ID_NULL))
    {
        if (pMpHead->mp_valid == MP_VALID)
        {
            pValidHead = pMpHead;
            break;
		    }

        pMpHead = GetNextMpId(pMpHead);
    }

    return pValidHead;
}

mp_sector_head_t * GetNextValidMpId(mp_sector_head_t *pMpHead)
{
    mp_sector_head_t *pValidHead = NULL;

    if (pMpHead != NULL)
    {
        pValidHead = GetFirstValidMpId(GetNextMpId(pMpHead));
    }

    return pValidHead;
}


mp_sector_head_t * GetSpecValidMpId(uint32_t spec_mp_id)
{
    mp_sector_head_t *pMpHead;

    pMpHead = GetFirstValidMpId((mp_sector_head_t *)((mp_sector_cal_t *)MP_SECTOR_INFO->CAL_DATA_SECTOR_ADDR));

    while (pMpHead != NULL)
    {
        if (pMpHead->mp_id == spec_mp_id)
        {
            break;
				}

        pMpHead = GetNextValidMpId(pMpHead);
    }

    return pMpHead;
}

mp_sector_head_t * GetNullMpId(void)
{
    uint32_t mp_next = 0;
    mp_sector_head_t *pMpHead;
    mp_sector_head_t *pNullMpHead = NULL;

    pMpHead = (mp_sector_head_t *)((mp_sector_cal_t *)MP_SECTOR_INFO->CAL_DATA_SECTOR_ADDR);

    while (pMpHead != NULL)
    {
        if (pMpHead->mp_id == MP_ID_NULL)
        {
            pNullMpHead = pMpHead;
            break;
		    }

        if (pMpHead->mp_cnt == 0)
        {
            break;
        }

        mp_next = (uint32_t)pMpHead;
        mp_next += pMpHead->mp_cnt;
        pMpHead = (mp_sector_head_t *)mp_next;
    }

    return pNullMpHead;
}


void MpCalibrationInit(mp_sector_cal_t *cal_sector)
{
/*
    mp_cal_regulator_t mp_cal;
    uint8_t flag;
    uint8_t target_vosel;

    mp_cal = cal_sector->DCDC;

    flag = mp_cal.flag;

    switch (mp_cal.select)
    {
        case 1:
            target_vosel = mp_cal.target_vosel_1;
            break;

        case 2:
            target_vosel = mp_cal.target_vosel_2;
            break;

        case 3:
            target_vosel = mp_cal.target_vosel_3;
            break;

        default:
            flag = 0;
            break;
    }

    if (flag == 1)
    {
        PMU->PMU_VOUT_SEL0.bit.DCDC_VOSEL_NM = target_vosel;
        PMU->PMU_VOUT_SEL0.bit.DCDC_VOSEL_SP = target_vosel;
        PMU->PMU_VOUT_SEL0.bit.DCDC_VOSEL_DS = target_vosel;
    }
*/
/*
    mp_cal_regulator_t *mp_cal;
    mp_cal = (mp_cal_regulator_t *)&cal_sector->DCDC;
    MpCalDcdcInit(mp_cal);
*/
/*
    mp_sector_head_t *pMpHead;

    pMpHead = (mp_sector_head_t *)cal_sector;

    pMpHead = GetFirstValidMpId((mp_sector_head_t *)cal_sector);
    pMpHead = GetNextValidMpId(pMpHead);

    MpCalDcdcInit((mp_cal_regulator_t *)&cal_sector->DCDC);
*/

    mp_sector_head_t *pMpHead;

    pMpHead = GetFirstValidMpId((mp_sector_head_t *)cal_sector);

    while (pMpHead != NULL)
    {
        switch (pMpHead->mp_id)
        {
            case MP_ID_DCDC:
                MpCalDcdcInit((mp_cal_regulator_t *)&cal_sector->DCDC);
                break;

            case MP_ID_LLDO:
                MpCalLldoInit((mp_cal_regulator_t *)&cal_sector->LLDO);
                break;

            case MP_ID_IOLDO:
                MpCalIoldoInit((mp_cal_regulator_t *)&cal_sector->IOLDO);
                break;

            case MP_ID_SLDO:
                MpCalSldoInit((mp_cal_regulator_t *)&cal_sector->SLDO);
                break;

            case MP_ID_SIOLDO:
                MpCalSioldoInit((mp_cal_regulator_t *)&cal_sector->SIOLDO);
                break;

            case MP_ID_POWERFAIL:
                MpCalPowerfailInit((mp_cal_regulator_t *)&cal_sector->POWER_FAIL);
                break;

            case MP_ID_CRYSTALTRIM:
                MpCalCrystaltrimInit((mp_cal_xtal_trim_t *)&cal_sector->CRYSTAL_TRIM);
                break;

            default:
                break;
				}

        pMpHead = GetNextValidMpId(pMpHead);
    }
}


void MpSectorInit(void)
{
    uint32_t ver, size;

    ver = MP_SECTOR_INFO->MP_SECTOR_VERSION;
    size = MP_SECTOR_INFO->MP_SECTOR_SIZE;

    do
    {
        if ((ver != MP_SECTOR_VERSION_DEFINE) || (size != MP_SECTOR_TOTAL_SIZE))
        {
            break;
		    }

        if (MP_SECTOR_INFO->CAL_DATA_SECTOR_SIZE <= MP_SECTOR_CAL_SIZE)
        {
            MpCalibrationInit((mp_sector_cal_t *)MP_SECTOR_INFO->CAL_DATA_SECTOR_ADDR);
        }

    } while(0);
}


/** @} */

