/** @file bsp_led.h
 * @license
 * @description
 */

#ifndef __BSP_LED_H__
#define __BSP_LED_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "bsp.h"

#define BSP_LED_COUNT   2
#define BSP_LED_0       20
#define BSP_LED_1       21
#define BSP_LED_ACTIVE_STATE    0

typedef struct 
{
    uint32_t pin_no;
} bsp_led_cfg_t;

int bsp_led_init(bsp_event_callback_t callback);
void bsp_led_on(uint32_t led);
void bsp_led_Off(uint32_t led);
void bsp_led_toggle(uint32_t led);


#ifdef __cplusplus
}
#endif

#endif
