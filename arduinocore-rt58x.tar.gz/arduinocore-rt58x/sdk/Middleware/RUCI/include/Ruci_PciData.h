/******************************************************************************
*
* @File			Ruci_PciData.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_PCI_DATA_H
#define _RUCI_PCI_DATA_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_PCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_PCI_DATA_HEADER 0x17

// RUCI: SetTxControlField -----------------------------------------------------
#define RUCI_SET_TX_CONTROL_FIELD               RUCI_NUM_SET_TX_CONTROL_FIELD, Ruci_ElmtType_SetTxControlField, Ruci_ElmtNum_SetTxControlField
#define RUCI_CODE_SET_TX_CONTROL_FIELD          0x01
#define RUCI_LEN_SET_TX_CONTROL_FIELD           6
#define RUCI_NUM_SET_TX_CONTROL_FIELD           5
#define RUCI_PARA_LEN_SET_TX_CONTROL_FIELD      2
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetTxControlField[];
extern const uint8_t Ruci_ElmtNum_SetTxControlField[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_TX_CONTROL_FIELD {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint8_t         MacControl;
    uint8_t         MacDsn;
} sRUCI_PARA_SET_TX_CONTROL_FIELD;

// RUCI: RxControlField --------------------------------------------------------
#define RUCI_RX_CONTROL_FIELD                   RUCI_NUM_RX_CONTROL_FIELD, Ruci_ElmtType_RxControlField, Ruci_ElmtNum_RxControlField
#define RUCI_CODE_RX_CONTROL_FIELD              0x02
#define RUCI_LEN_RX_CONTROL_FIELD               7
#define RUCI_NUM_RX_CONTROL_FIELD               6
#define RUCI_PARA_LEN_RX_CONTROL_FIELD          3
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_RxControlField[];
extern const uint8_t Ruci_ElmtNum_RxControlField[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_RX_CONTROL_FIELD {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint16_t        Length;
    uint8_t         CrcStatus;
    uint8_t         Rssi;
    uint8_t         Snr;
} sRUCI_PARA_RX_CONTROL_FIELD;

#pragma pack(pop)
#endif /* RUCI_ENABLE_PCI */
#endif /* _RUCI_PCI_DATA_H */
