/** @file
 *
 * @brief Delay driver file.
 *
 */

#ifndef __DELAY_H__
#define __DELAY_H__

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/


/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/
/**
 * @brief Delay us handler prototype.
 *
 * This function is called when the requested number of delay us has been processed.
 *
 * @param number_of_us number of delay us.
 */
typedef void (*delay_us_t)(uint32_t volatile number_of_us);


/**
 * @brief Delay ms handler prototype.
 *
 * This function is called when the requested number of delay ms has been processed.
 *
 * @param number_of_ms number of delay ms.
 */
typedef void (*delay_ms_t)(uint32_t volatile number_of_ms);


/**************************************************************************************************
 *    Global Prototypes
 *************************************************************************************************/
void Delay_Init(void);
extern delay_us_t Delay_us;
extern delay_ms_t Delay_ms;


#endif /* end of _DELAY_H_ */

