/**************************************************************************//**
 * @file     sysfun.c
 * @version
 * @brief    System function implement
 *
 * @copyright
 ******************************************************************************/
#include "assert_help.h"
#include "cm3_mcu.h"

#include "project_config.h"

#if (MODULE_ENABLE(SUPPORT_MULTITASKING)) 
#include "FreeRTOS.h"
#include "task.h"
#endif

static int critical_counter=0;

void enter_critical_section(void)
{
    __disable_irq();

    critical_counter++;
}

void leave_critical_section(void)
{
    critical_counter--;
    assert_param(critical_counter >=0);

    if (critical_counter == 0) {
        __enable_irq();
    }
}


/*
 *      version_check is help function to check
 *   software project setting is the same as hardware IC version.
 *   If software project define "CHIP_VERSION" is
 *   not matched with hardware IC version, this functio will return 0, otherwise 1.
 *
 */
uint32_t version_check(void)
{
    
    uint32_t   version_info , ret=1, chip_id, chip_rev;

    version_info =  SYSCTRL->CHIP_INFO ;

    chip_id =  version_info & IC_CHIP_ID_MASK;
    chip_rev = version_info & IC_CHIP_REVISION_MASK;
    
#if (CHIP_VERSION == RT58X_MPA)

    if ((chip_id!=IC_RT58X) || (chip_rev!=IC_CHIP_REVISION_MPA)) {
        return 0;       /*hardware is different from software setting*/
    }

#elif (CHIP_VERSION == RT58X_MPB)

    if ((chip_id!=IC_RT58X) || (chip_rev!=IC_CHIP_REVISION_MPB))  {
        return 0;       /*hardware is different from software setting*/
    }

#elif (CHIP_VERSION == RT58X_SHUTTLE)

   #error "SHUTTLE IC has been *** OBSOLETED!! ***"

#endif




    return ret;

}

