/**
 * @file rfb_port.c
 * @author
 * @date
 * @brief porting ruci related function for RFB used
 *
 * More detailed description can go here
 *
 *
 * @see http://
 */
/**************************************************************************************************
*    INCLUDES
*************************************************************************************************/
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "cm3_mcu.h"

#include "rfb_comm.h"
#include "rfb_port.h"
#include "Ruci.h"
#include "chip_define.h"

/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/
#define ADDR_RFB_STATE                         (0x0198)
#define R_RFB_STATE                             0x08, 0x00000700

#define ADDR_PKT_FMT                           (0x0100)
#define R_CRC_TYPE                             0x04, 0x00000030


/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/
rfb_t g_rfb;

/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/
void  reg_cal(
    uint32_t *reg_value,
    uint8_t bitShift,
    uint32_t bitMask,
    uint32_t data
)
{
    *reg_value &= (~bitMask);
    *reg_value |= ((data << bitShift) & bitMask);
}

void  reg_byte_invert(
    uint32_t reg_value,
    uint8_t bitShift,
    uint32_t bitMask,
    uint8_t *data
)
{
    reg_value &= (bitMask);
    *data = (uint8_t)((reg_value >> bitShift) & 0xFF);
}


/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/
void rfb_port_modem_set(rfb_modem_type_t modem)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;

    if (g_rfb.modem_type == modem)
        return;
    g_rfb.modem_type = modem;

    switch (modem) {
#if (defined RFB_ZIGBEE_ENABLED && RFB_ZIGBEE_ENABLED == 1)
    case RFB_MODEM_ZIGBEE:
        event_status = rfb_comm_zigbee_initiate();
        if (event_status != RFB_EVENT_SUCCESS)
            printf("[W] rfb_comm_zigbee_initiate fail, status:%d\n", event_status);
        break;
#endif

#if (defined RFB_WISUN_ENABLED && RFB_WISUN_ENABLED == 1)
    case RFB_MODEM_FSK:
        event_status = rfb_comm_fsk_initiate(BAND_SUBG);
        if (event_status != RFB_EVENT_SUCCESS)
            printf("[W] rfb_comm_fsk_initiate fail, status:%d\n", event_status);
        break;
#endif

    }


}

#if (defined RFB_ZIGBEE_ENABLED && RFB_ZIGBEE_ENABLED == 1)
void rfb_port_zb_init(rfb_interrupt_event_t *_rfb_interrupt_event)
{
    rfb_comm_init(_rfb_interrupt_event);

#if (CHIP_VERSION == RT58X_MPA)
    /* Enable 569 P0 */
#if 0 /* disable for FW testing & debug mode and made bug issues from Zigbee button ISR */
    outp32(0x40800010, 0x77777777);
    outp32(0x4080003C, ((inp32(0x4080003C) & 0xF0FFFFFF) | 0x07000000)); //P0
    //outp32(0x4080003C, ((inp32(0x4080003C) & 0xF0FFFFFF)| 0x01000000)); //modem
#endif
#endif

    /*Set the initial modem type*/
    rfb_port_modem_set(RFB_MODEM_ZIGBEE);
}
#endif

#if (defined RFB_WISUN_ENABLED && RFB_WISUN_ENABLED == 1)
void rfb_port_wisun_init(rfb_interrupt_event_t *_rfb_interrupt_event)
{
    rfb_comm_init(_rfb_interrupt_event);
#if (CHIP_VERSION == RT58X_MPA)
    /* Enable 569 P0 */
#if 0
    outp32(0x40800010, 0x77777777);
    outp32(0x4080003C, ((inp32(0x4080003C) & 0xF0FFFFFF) | 0x07000000)); //P0
    //outp32(0x4080003C, ((inp32(0x4080003C) & 0xF0FFFFFF)| 0x01000000)); //modem
#endif
#endif
    /*Set the initial modem type*/
    rfb_port_modem_set(RFB_MODEM_FSK);
    g_rfb.modem_type = RFB_MODEM_FSK;
}
#endif


void rfb_port_frequency_set(uint32_t rf_frequency)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    event_status = rfb_comm_frequency_set(rf_frequency);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_frequency_set fail, status:%d\n", event_status);
}

#if (defined RFB_ZIGBEE_ENABLED && RFB_ZIGBEE_ENABLED == 1)
bool rfb_port_zb_is_channel_free(uint32_t rf_frequency, uint8_t rssi_threshold)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    uint8_t rssi = 0;
    bool is_channel_free;

    /* Set RF frequency */
    event_status = rfb_comm_frequency_set(rf_frequency);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_frequency_set fail, status:%d\n", event_status);

    /* Enable RX*/
    rfb_port_auto_state_set(true);

    /* Get rssi */
    event_status = rfb_comm_rssi_read(&rssi);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rssi_read fail, status:%d\n", event_status);

    /* Disable RX*/
    rfb_port_auto_state_set(false);

    /* determine channel status*/
    is_channel_free = (rssi > rssi_threshold) ? true : false;

    return is_channel_free;
}
#endif

#if (defined RFB_WISUN_ENABLED && RFB_WISUN_ENABLED == 1)
bool rfb_port_wisun_is_channel_free(uint32_t rf_frequency, uint8_t rssi_threshold)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    uint8_t rssi = 0;
    bool is_channel_free;

    /* Init idle state */
    event_status = rfb_comm_rf_idle_set();
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rf_idle_set fail, status:%d\n", event_status);

    /*Init Modem */
    rfb_port_modem_set(RFB_MODEM_FSK);

    /* Set RF frequency */
    event_status = rfb_comm_frequency_set(rf_frequency);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_frequency_set fail, status:%d\n", event_status);

    /* Enable RX*/
    event_status = rfb_comm_rx_enable_set(true, 0);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rx_enable_set fail, status:%d\n", event_status);

    /* Get rssi */
    event_status = rfb_comm_rssi_read(&rssi);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rssi_read fail, status:%d\n", event_status);

    /* go back to idle state */
    event_status = rfb_comm_rf_idle_set();
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rf_idle_set fail, status:%d\n", event_status);

    /* determine channel status*/
    is_channel_free = (rssi > rssi_threshold) ? true : false;

    return is_channel_free;
}
#endif

void rfb_port_data_send(uint8_t *tx_data_address, uint16_t packet_length, uint8_t InitialCwAckRequest, uint8_t Dsn)
{
    RFB_WRITE_TXQ_STATUS rfb_write_tx_queue_status;
    rfb_write_tx_queue_status = rfb_comm_tx_data_send(packet_length, tx_data_address, InitialCwAckRequest, Dsn);
    if (rfb_write_tx_queue_status != RFB_WRITE_TXQ_SUCCESS)
        printf("[W] Send TX fail\n");
}

void rfb_port_tx_continuous_wave_set(uint32_t rf_frequency, tx_power_level_t tx_power)
{
    static uint8_t dummy_tx_data[10];
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    RFB_WRITE_TXQ_STATUS rfb_write_tx_queue_status;
    /*Set RF State to Idle*/
    event_status = rfb_comm_rf_idle_set();
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rf_idle_set fail, status:%d\n", event_status);

    /*
    * Set channel frequency :
    * For band is subg, units is kHz
    * For band is 2.4g, units is mHz
    */
    event_status = rfb_comm_frequency_set(rf_frequency);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_frequency_set fail, status:%d\n", event_status);

    event_status = rfb_comm_single_tone_mode_set(2);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_single_tone_mode_set fail, status:%d\n", event_status);

    rfb_write_tx_queue_status = rfb_comm_tx_data_send(10, &dummy_tx_data[0], 0, 0);
    if (rfb_write_tx_queue_status != RFB_WRITE_TXQ_SUCCESS)
        printf("[W] rfb_comm_tx_data_send fail, status:%d\n", rfb_write_tx_queue_status);
}

uint8_t rfb_port_rssi_read(rfb_modem_type_t modem)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    uint8_t rssi;
    event_status = rfb_comm_rssi_read(&rssi);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rssi_read fail, status:%d\n", event_status);
    return rssi;
}



#if (defined RFB_ZIGBEE_ENABLED && RFB_ZIGBEE_ENABLED == 1)
void rfb_port_15p4_address_filter_set(uint8_t mac_promiscuous_mode, uint16_t short_source_address, uint32_t long_source_address_0, uint32_t long_source_address_1, uint16_t pan_id, uint8_t isCoordinator)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    event_status = rfb_comm_15p4_address_filter_set(mac_promiscuous_mode, short_source_address, long_source_address_0, long_source_address_1, pan_id, isCoordinator);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_15p4_address_filter_set fail, status:%d\n", event_status);
}

void rfb_port_15p4_mac_pib_set(uint32_t a_unit_backoff_period, uint32_t mac_ack_wait_duration, uint8_t mac_max_BE, uint8_t mac_max_CSMA_backoffs,
                                   uint32_t mac_max_frame_total_wait_time, uint8_t mac_max_frame_retries, uint8_t mac_min_BE)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    event_status = rfb_comm_15p4_mac_pib_set(a_unit_backoff_period, mac_ack_wait_duration, mac_max_BE, mac_max_CSMA_backoffs, mac_max_frame_total_wait_time, 
                                  mac_max_frame_retries, mac_min_BE);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_15p4_mac_pib_set fail, status:%d\n", event_status);
}

void rfb_port_15p4_phy_pib_set(uint16_t a_turnaround_time, uint8_t phy_cca_mode, uint8_t phy_cca_threshold, uint16_t phy_cca_duration)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    event_status = rfb_comm_15p4_phy_pib_set(a_turnaround_time, phy_cca_mode, phy_cca_threshold, phy_cca_duration);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_15p4_phy_pib_set fail, status:%d\n", event_status);
}

void rfb_port_15p4_auto_ack_set(uint8_t auto_ack_enable)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    event_status = rfb_comm_15p4_auto_ack_set(auto_ack_enable);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_15p4_auto_ack_set fail, status:%d\n", event_status);
}

void rfb_port_15p4_pending_bit_set(uint8_t pending_bit_enable)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    event_status = rfb_comm_15p4_pending_bit_set(pending_bit_enable);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_15p4_pending_bit_set fail, status:%d\n", event_status);
}
#endif

void rfb_port_auto_state_set(bool rxOnWhenIdle)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    event_status = rfb_comm_auto_state_set(rxOnWhenIdle);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_port_auto_state_set fail, status:%d\n", event_status);
}

uint32_t rfb_port_version_get(void)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    uint32_t fwVer;
    event_status = rfb_comm_fw_version_get(&fwVer);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_port_version_get fail, status:%d\n", event_status);
    return fwVer;
}

#if (defined RFB_WISUN_ENABLED && RFB_WISUN_ENABLED == 1)
void rfb_port_wisun_rx_config_set(uint8_t data_rate, uint16_t preamble_len, fsk_mod_t mod_idx, fsk_crc_type_t crc_type,
                                  whiten_enable_t whiten_enable, uint32_t rx_timeout, bool rx_continuous)

{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;

    g_rfb.rx_continuous = rx_continuous;
    if (rx_continuous == false)
        g_rfb.rx_timeout = rx_timeout;

    /*Set Gfsk data rate and modulation index*/
    event_status = rfb_comm_fsk_modem_set(data_rate, mod_idx);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_fsk_modem_set fail, status:%d\n", event_status);

    /*Set fsk crc type and whitening*/
    event_status = rfb_comm_fsk_mac_set(crc_type, whiten_enable);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_fsk_mac_set fail, status:%d\n", event_status);

    /* For Wisun, the preamble length is 8 bytes and preamble type is 10101010*/
    event_status = rfb_comm_fsk_preamble_set(preamble_len);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_fsk_preamble_set fail, status:%d\n", event_status);

    /* For Wisun, the sfd length is 2 bytes and sfd content is 0x00007209*/
    event_status = rfb_comm_fsk_sfd_set(0x00007209);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_fsk_sfd_set fail, status:%d\n", event_status);

}

void rfb_port_wisun_tx_config_set(tx_power_level_t tx_power, uint8_t data_rate, uint16_t preamble_len, fsk_mod_t mod_idx,
                                  fsk_crc_type_t crc_type, whiten_enable_t whiten_enable)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;

    /*Set Gfsk data rate and modulation index*/
    event_status = rfb_comm_fsk_modem_set(data_rate, mod_idx);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_fsk_modem_set fail, status:%d\n", event_status);

    /*Set fsk crc type and whitening*/
    event_status = rfb_comm_fsk_mac_set(crc_type, whiten_enable);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_fsk_mac_set fail, status:%d\n", event_status);

    /* For Wisun, the preamble length is 8 bytes and preamble type is 10101010*/
    event_status = rfb_comm_fsk_preamble_set(preamble_len);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_fsk_preamble_set fail, status:%d\n", event_status);

    /* For Wisun, the sfd length is 2 bytes and sfd content is 0x00007209*/
    event_status = rfb_comm_fsk_sfd_set(0x00007209);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_fsk_sfd_set fail, status:%d\n", event_status);
}

void rfb_port_sleep_set(void)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;
    event_status = rfb_comm_rf_sleep_set(true);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rf_sleep_set fail, status:%d\n", event_status);
}

void rfb_port_idle_set(void)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;

    event_status = rfb_comm_rf_sleep_set(false);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rf_sleep_set fail, status:%d\n", event_status);

    event_status = rfb_comm_rf_idle_set();
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rf_idle_set fail, status:%d\n", event_status);
}

void rfb_port_rx_start(void)
{
    RFB_EVENT_STATUS event_status = RFB_EVENT_SUCCESS;

    event_status = rfb_comm_rf_sleep_set(false);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rf_sleep_set fail, status:%d\n", event_status);

    event_status = rfb_comm_rx_enable_set(g_rfb.rx_continuous, g_rfb.rx_timeout);
    if (event_status != RFB_EVENT_SUCCESS)
        printf("[W] rfb_comm_rx_enable_set fail, status:%d\n", event_status);
}
#endif

