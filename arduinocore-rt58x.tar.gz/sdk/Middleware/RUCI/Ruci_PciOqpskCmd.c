/******************************************************************************
*
* @File			Ruci_PciOqpskCmd.c
* @Version
* $Revision:4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_PciOqpskCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_PCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: InitiateOqpsk ---------------------------------------------------------
const uint8_t Ruci_ElmtType_InitiateOqpsk[] = {
    1, 1, 1
};
const uint8_t Ruci_ElmtNum_InitiateOqpsk[] = {
    1, 1, 1
};

// RUCI: SetOqpskModem ---------------------------------------------------------
const uint8_t Ruci_ElmtType_SetOqpskModem[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetOqpskModem[] = {
    1, 1, 1, 1
};

// RUCI: SetOqpskMac -----------------------------------------------------------
const uint8_t Ruci_ElmtType_SetOqpskMac[] = {
    1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetOqpskMac[] = {
    1, 1, 1, 1, 1
};

// RUCI: SetOqpskExtraPreamble -------------------------------------------------
const uint8_t Ruci_ElmtType_SetOqpskExtraPreamble[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetOqpskExtraPreamble[] = {
    1, 1, 1, 1
};

#endif /* RUCI_ENABLE_PCI */
#endif /* RUCI_ENDIAN_INVERSE */
