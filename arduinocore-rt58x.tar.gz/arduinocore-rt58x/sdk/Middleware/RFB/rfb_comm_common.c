/**
 * @file rfb_comm_common.c
 * @author
 * @date
 * @brief Apis for RFB communication subsystem and ruci format
 *
 * More detailed description can go here
 *
 *
 * @see http://
 */
/**************************************************************************************************
*    INCLUDES
*************************************************************************************************/
#include <string.h>
#include <stdio.h>
#include "cm3_mcu.h"
#include "Ruci.h"
#include "rfb_comm.h"
#include "rfb.h"
#include "rf_common_init.h"
/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/

/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/
#define RX_ALWAYS_ON_MODE (0xFFFFFFFF)

/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/
typedef struct _rfb_rx_ctrl_field_t {
    uint16_t        Length;
    uint8_t         CrcStatus;
    uint8_t         Rssi;
    uint8_t         Snr;
} rfb_rx_ctrl_field_t;

typedef struct _rfb_rx_buffer_s {
    rfb_rx_ctrl_field_t rx_control_field;
    uint8_t rx_data[MAX_RF_LEN];
} rfb_rx_buffer_t;

typedef struct _rfb_rx_queue_t {
    uint8_t rx_num;
    rfb_rx_buffer_t rx_buf[MAX_RX_BUFF_NUM];
} rfb_rx_queue_t;

/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/
rfb_interrupt_event_t *rfb_interrupt_event;
static rfb_rx_queue_t g_rx_queue;
extern void enter_critical_section(void);
extern void leave_critical_section(void);
extern void commsubsystem_read_memory(uint16_t reg_address, uint8_t *p_rx_data, uint16_t rx_data_length);
/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/

RF_MCU_RX_CMDQ_ERROR rfb_event_read(uint8_t *packet_length, uint8_t *event_address)
{
    RF_MCU_RX_CMDQ_ERROR rx_confirm_error = RF_MCU_RX_CMDQ_ERR_INIT;
    uint8_t state = 0;
    do {
        state = (uint8_t)commsubsystem_read_mcu_state();
        state = state & RF_MCU_STATE_EVENT_DONE;
    } while (RF_MCU_STATE_EVENT_DONE != state);
    commsubsystem_send_host_cmd(RF_MCU_STATE_EVENT_DONE);
    state = 0;
    do {
        state = (uint8_t)commsubsystem_read_mcu_state();
        state = state & RF_MCU_STATE_EVENT_DONE;
    } while (0 != state);

    (*packet_length)  = commsubsystem_read_cmd_queue(event_address, &rx_confirm_error);


    return rx_confirm_error;
}

RF_MCU_RXQ_ERROR rfb_comm_rx_data_read(uint8_t *rx_data_address, rfb_rx_ctrl_field_t *rx_control_field)
{
    RF_MCU_RXQ_ERROR RxQueueError = RF_MCU_RXQ_ERR_INIT;
    commsubsystem_read_rx_queue(rx_data_address, &RxQueueError);
    RUCI_ENDIAN_CONVERT((uint8_t *)&sRxControlField, RUCI_RX_CONTROL_FIELD);
    /* Crc status , Rssi , and SNR will be put on first three byte of RX queue*/
    memcpy((uint8_t *)rx_control_field, &rx_data_address[2], RUCI_LEN_RX_CONTROL_FIELD - 2);
    return RxQueueError;
}

void rfb_send_cmd(uint8_t *cmd_address, uint8_t cmd_length)
{
    /* wake up RF to clear interrupt status */
    commsubsystem_host_wakeup();
    while (commsubsystem_check_power_state() != 0x03) {
        //printf("[W] PWR state error(%d) in rfb_send_cmd\n",commsubsystem_check_power_state());
    }
    while (RF_MCU_TX_CMDQ_SET_SUCCESS != commsubsystem_send_cmd_queue(cmd_address, cmd_length)) {
        printf("[E] command queue is FULL\n");
    }
}
/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/

void rfb_isr_handler(uint8_t interrupt_status)
{
    static COMM_SUBSYSTEM_INTERRUPT interrupt_state_value;
    uint32_t pro_grm_cnt;
    uint8_t tx_status, rx_numIdx;
    bool isRemainingRxQ;
    RF_MCU_RXQ_ERROR rxq_status = RF_MCU_RXQ_ERR_INIT;
    static rfb_rx_queue_t *pRxQueue = &g_rx_queue;
    interrupt_state_value.u8 = interrupt_status;

    /* wake up RF to clear interrupt status */
    commsubsystem_host_wakeup();
    if (commsubsystem_check_power_state() != 0x03) {
        /* FOR LEVEL TRIGGER ONLY, the MCU will keep entering INT if status not cleared */
        printf("[W] PWR state error in rfb_isr_handler\n");
        return;
    }

    if (interrupt_state_value.bf.EVENT_DONE) {
        commsubsystem_clean_interrupt((interrupt_status & 0x01));
    }
    if (interrupt_state_value.bf.TX_DONE) {
        /* Read Tx Status */
        tx_status = (uint8_t)commsubsystem_read_mcu_state();

        /* Clear MCU state by sending host command */
        commsubsystem_send_host_cmd((tx_status & 0xF4));
        commsubsystem_clean_interrupt((interrupt_status & 0x02));
        rfb_interrupt_event->tx_done(tx_status);
    }
    if (interrupt_state_value.bf.RFB_TRAP) {
        printf("[Error] RFB Trap !!!\n");
        commsubsystem_read_memory(0x4008, (uint8_t *)&pro_grm_cnt, 4);
        printf("PC= %X\n", pro_grm_cnt);
        commsubsystem_read_memory(0x01E0, (uint8_t *)&pro_grm_cnt, 4);
        printf("MAC err status= %X\n", pro_grm_cnt);
        commsubsystem_read_memory(0x0198, (uint8_t *)&pro_grm_cnt, 4);
        printf("MAC task status= %X\n", pro_grm_cnt);
        commsubsystem_read_memory(0x0048, (uint8_t *)&pro_grm_cnt, 4);
        printf("BMU err status= %X\n", pro_grm_cnt);
        commsubsystem_clean_interrupt((interrupt_status & 0x04));
        while (1);
    }
    if (interrupt_state_value.bf.RX_DONE) {
        commsubsystem_clean_interrupt((interrupt_status & 0x20));
        g_rx_queue.rx_num = 0;
        do {
            rxq_status = rfb_comm_rx_data_read(pRxQueue->rx_buf[g_rx_queue.rx_num].rx_data, &pRxQueue->rx_buf[g_rx_queue.rx_num].rx_control_field);
            if (rxq_status != RF_MCU_RXQ_GET_SUCCESS)
                return;
            isRemainingRxQ = commsubsystem_check_rx_queue();
            g_rx_queue.rx_num ++;
            if (g_rx_queue.rx_num > MAX_RX_BUFF_NUM)
                return;
        } while (isRemainingRxQ);

        for (rx_numIdx = 0; rx_numIdx < g_rx_queue.rx_num; rx_numIdx++)
            rfb_interrupt_event->rx_done(pRxQueue->rx_buf[rx_numIdx].rx_control_field.Length, pRxQueue->rx_buf[rx_numIdx].rx_data, pRxQueue->rx_buf[rx_numIdx].rx_control_field.CrcStatus,
                                         pRxQueue->rx_buf[rx_numIdx].rx_control_field.Rssi, pRxQueue->rx_buf[rx_numIdx].rx_control_field.Snr);

    }

    if (interrupt_state_value.bf.RTC_WAKEUP) {
        commsubsystem_clean_interrupt((interrupt_status & 0x80));
    }
     if (interrupt_state_value.bf.RX_TIMEOUT) {
        commsubsystem_clean_interrupt((interrupt_status & 0x08));
        rfb_interrupt_event->rx_timeout();
    }
    if (interrupt_state_value.bf.MHR_DONE) {
        commsubsystem_clean_interrupt((interrupt_status & 0x10));
    }

}

RFB_EVENT_STATUS rfb_comm_frequency_set(uint32_t rf_frequency)
{
    sRUCI_PARA_SET_RF_FREQUENCY sSetFrequencyCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RF_CHANNEL(&sSetFrequencyCmd, rf_frequency);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sSetFrequencyCmd, RUCI_SET_RF_FREQUENCY);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sSetFrequencyCmd, RUCI_LEN_SET_RF_FREQUENCY);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RF_FREQUENCY)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_single_tone_mode_set(uint8_t single_tone_mode)
{
    sRUCI_PARA_SET_SINGLE_TONE_MODE sStModeEnCmd_t = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_SINGLE_TONE(&sStModeEnCmd_t, single_tone_mode);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sStModeEnCmd_t, RUCI_SET_SINGLE_TONE_MODE);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sStModeEnCmd_t, RUCI_LEN_SET_SINGLE_TONE_MODE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_SINGLE_TONE_MODE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;
    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_rx_enable_set(bool rx_continuous, uint32_t rx_timeout)
{
    sRUCI_PARA_SET_RX_ENABLE sRxReqCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RX_ENABLE(&sRxReqCmd, ((rx_continuous == true) ? RX_ALWAYS_ON_MODE : rx_timeout));

    RUCI_ENDIAN_CONVERT((uint8_t *)&sRxReqCmd, RUCI_SET_RX_ENABLE);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sRxReqCmd, RUCI_LEN_SET_RX_ENABLE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RX_ENABLE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}


RFB_EVENT_STATUS rfb_comm_rf_idle_set(void)
{
    sRUCI_PARA_SET_RF_IDLE sRfIdleSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RF_IDLE(&sRfIdleSetCmd);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sRfIdleSetCmd, RUCI_SET_RF_IDLE);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sRfIdleSetCmd, RUCI_LEN_SET_RF_IDLE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RF_IDLE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}


RFB_WRITE_TXQ_STATUS rfb_comm_tx_data_send(uint16_t packet_length, uint8_t *tx_data_address, uint8_t control, uint8_t Dsn)
{
    sRUCI_PARA_SET_TX_CONTROL_FIELD sTxControlField = {0};
    static uint8_t txData[MAX_RF_LEN];

    /* wake up RF to clear interrupt status */
    commsubsystem_host_wakeup();
    while (commsubsystem_check_power_state() != 0x03) {
        printf("[TX] Pwr chk\n");
    }

    SET_RUCI_PARA_TX_CONTROL_FIELD(&sTxControlField, packet_length, control, Dsn);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sTxControlField, RUCI_SET_TX_CONTROL_FIELD);
    memcpy(&txData[0], (uint8_t *)&sTxControlField, RUCI_LEN_SET_TX_CONTROL_FIELD);
    memcpy(&txData[RUCI_LEN_SET_TX_CONTROL_FIELD], tx_data_address, packet_length);

    if (RF_MCU_TXQ_FULL == commsubsystem_send_tx_queue(RF_TX_Q_ID, &txData[0], packet_length + RUCI_LEN_SET_TX_CONTROL_FIELD))
        return RFB_WRITE_TXQ_FULL;
    return RFB_WRITE_TXQ_SUCCESS;

}

void rfb_comm_init(rfb_interrupt_event_t *_rfb_interrupt_event)
{
    /* Rsgister Interrupt event for application use*/
    rfb_interrupt_event = _rfb_interrupt_event;

    rf_common_init_by_fw(RF_FW_LOAD_SELECT_RUCI_CMD,rfb_isr_handler);
}

RFB_EVENT_STATUS rfb_comm_rssi_read(uint8_t *rssi)
{
    sRUCI_PARA_GET_RSSI sGetRssiCmd = {0};
    sRUCI_PARA_GET_RSSI_EVENT sGetRssiEvent = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;
    uint8_t get_rssi_event_len = 0;
    RF_MCU_RX_CMDQ_ERROR get_rssi_event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_GET_RSSI(&sGetRssiCmd);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRssiCmd, RUCI_GET_RSSI);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sGetRssiCmd, RUCI_LEN_GET_RSSI);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    get_rssi_event_status = rfb_event_read(&get_rssi_event_len, (uint8_t *)&sGetRssiEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_GET_RSSI)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRssiEvent, RUCI_GET_RSSI_EVENT);
    if (get_rssi_event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_RSP_EVENT_NOT_AVAILABLE;
    if (sGetRssiEvent.Subheader != RUCI_CODE_GET_RSSI_EVENT)
        return RFB_RSP_EVENT_CONTENT_ERROR;
    *rssi = sGetRssiEvent.Rssi;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_agc_set(uint8_t agc_enable, uint8_t lna_gain, uint8_t vga_gain, uint8_t tia_gain)
{
    sRUCI_PARA_SET_AGC sAgcSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_AGC(&sAgcSetCmd, (agc_enable & 0x01), lna_gain, vga_gain, tia_gain);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sAgcSetCmd, RUCI_SET_AGC);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sAgcSetCmd, RUCI_LEN_SET_AGC);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_AGC)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_rf_sleep_set(bool sleep_enable_flag)
{
    sRUCI_PARA_SET_RF_SLEEP sRfSleepSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RF_SLEEP(&sRfSleepSetCmd, sleep_enable_flag);

    sRfSleepSetCmd.EnableFlag = sleep_enable_flag;

    RUCI_ENDIAN_CONVERT((uint8_t *)&sRfSleepSetCmd, RUCI_SET_RF_SLEEP);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sRfSleepSetCmd, RUCI_LEN_SET_RF_SLEEP);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RF_SLEEP)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_fw_version_get(uint32_t *rfb_version)
{
    sRUCI_PARA_GET_FW_VER sGetRfbVerCmd = {0};
    sRUCI_PARA_GET_FW_VER_EVENT sGetRfbVerEvent = {0};
    sRUCI_PARA_CMN_CNF_EVENT sCmnCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;
    uint8_t get_rfb_ver_event_len = 0;
    RF_MCU_RX_CMDQ_ERROR get_rfb_ver_event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_GET_FW_VER(&sGetRfbVerCmd);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRfbVerCmd, RUCI_GET_FW_VER);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sGetRfbVerCmd, RUCI_LEN_GET_FW_VER);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCmnCnfEvent);
    get_rfb_ver_event_status = rfb_event_read(&get_rfb_ver_event_len, (uint8_t *)&sGetRfbVerEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCmnCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCmnCnfEvent.CmnCmdSubheader != RUCI_CODE_GET_FW_VER)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCmnCnfEvent.Status != RFB_CMN_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCmnCnfEvent.Status;

    RUCI_ENDIAN_CONVERT((uint8_t *)&sGetRfbVerEvent, RUCI_GET_FW_VER_EVENT);
    if (get_rfb_ver_event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_RSP_EVENT_NOT_AVAILABLE;
    if (sGetRfbVerEvent.Subheader != RUCI_CODE_GET_FW_VER_EVENT)
        return RFB_RSP_EVENT_CONTENT_ERROR;
    *rfb_version = sGetRfbVerEvent.FwVer;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_auto_state_set(bool rxOnWhenIdle)
{
    sRUCI_PARA_SET_RFB_AUTO_STATE sRfbAutoStateSet = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_COMMON_RFB_AUTO_STATE(&sRfbAutoStateSet, rxOnWhenIdle);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sRfbStateInit, RUCI_SET_RFB_AUTO_STATE);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sRfbAutoStateSet, RUCI_LEN_SET_RFB_AUTO_STATE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET_RFB_AUTO_STATE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;
    return RFB_EVENT_SUCCESS;
}
