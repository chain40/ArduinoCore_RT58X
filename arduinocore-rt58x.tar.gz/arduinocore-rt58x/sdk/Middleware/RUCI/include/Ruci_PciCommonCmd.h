/******************************************************************************
*
* @File			Ruci_PciCommonCmd.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_PCI_COMMON_CMD_H
#define _RUCI_PCI_COMMON_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_PCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_PCI_COMMON_CMD_HEADER 0x10

// RUCI: SetRfFrequency --------------------------------------------------------
#define RUCI_SET_RF_FREQUENCY                   RUCI_NUM_SET_RF_FREQUENCY, Ruci_ElmtType_SetRfFrequency, Ruci_ElmtNum_SetRfFrequency
#define RUCI_CODE_SET_RF_FREQUENCY              0x01
#define RUCI_LEN_SET_RF_FREQUENCY               7
#define RUCI_NUM_SET_RF_FREQUENCY               4
#define RUCI_PARA_LEN_SET_RF_FREQUENCY          4
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfFrequency[];
extern const uint8_t Ruci_ElmtNum_SetRfFrequency[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RF_FREQUENCY {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        RfFrequency;
} sRUCI_PARA_SET_RF_FREQUENCY;

// RUCI: SetRxEnable -----------------------------------------------------------
#define RUCI_SET_RX_ENABLE                      RUCI_NUM_SET_RX_ENABLE, Ruci_ElmtType_SetRxEnable, Ruci_ElmtNum_SetRxEnable
#define RUCI_CODE_SET_RX_ENABLE                 0x03
#define RUCI_LEN_SET_RX_ENABLE                  7
#define RUCI_NUM_SET_RX_ENABLE                  4
#define RUCI_PARA_LEN_SET_RX_ENABLE             4
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRxEnable[];
extern const uint8_t Ruci_ElmtNum_SetRxEnable[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RX_ENABLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        RxOnTime;
} sRUCI_PARA_SET_RX_ENABLE;

// RUCI: SetSingleToneMode -----------------------------------------------------
#define RUCI_SET_SINGLE_TONE_MODE               RUCI_NUM_SET_SINGLE_TONE_MODE, Ruci_ElmtType_SetSingleToneMode, Ruci_ElmtNum_SetSingleToneMode
#define RUCI_CODE_SET_SINGLE_TONE_MODE          0x04
#define RUCI_LEN_SET_SINGLE_TONE_MODE           4
#define RUCI_NUM_SET_SINGLE_TONE_MODE           4
#define RUCI_PARA_LEN_SET_SINGLE_TONE_MODE      1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetSingleToneMode[];
extern const uint8_t Ruci_ElmtNum_SetSingleToneMode[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_SINGLE_TONE_MODE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         StMode;
} sRUCI_PARA_SET_SINGLE_TONE_MODE;

// RUCI: GetCrcCount -----------------------------------------------------------
#define RUCI_GET_CRC_COUNT                      RUCI_NUM_GET_CRC_COUNT, Ruci_ElmtType_GetCrcCount, Ruci_ElmtNum_GetCrcCount
#define RUCI_CODE_GET_CRC_COUNT                 0x0C
#define RUCI_LEN_GET_CRC_COUNT                  3
#define RUCI_NUM_GET_CRC_COUNT                  3
#define RUCI_PARA_LEN_GET_CRC_COUNT             0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetCrcCount[];
extern const uint8_t Ruci_ElmtNum_GetCrcCount[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_CRC_COUNT {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_GET_CRC_COUNT;

// RUCI: SetRfSleep ------------------------------------------------------------
#define RUCI_SET_RF_SLEEP                       RUCI_NUM_SET_RF_SLEEP, Ruci_ElmtType_SetRfSleep, Ruci_ElmtNum_SetRfSleep
#define RUCI_CODE_SET_RF_SLEEP                  0x0D
#define RUCI_LEN_SET_RF_SLEEP                   4
#define RUCI_NUM_SET_RF_SLEEP                   4
#define RUCI_PARA_LEN_SET_RF_SLEEP              1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfSleep[];
extern const uint8_t Ruci_ElmtNum_SetRfSleep[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RF_SLEEP {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         EnableFlag;
} sRUCI_PARA_SET_RF_SLEEP;

// RUCI: SetRfIdle -------------------------------------------------------------
#define RUCI_SET_RF_IDLE                        RUCI_NUM_SET_RF_IDLE, Ruci_ElmtType_SetRfIdle, Ruci_ElmtNum_SetRfIdle
#define RUCI_CODE_SET_RF_IDLE                   0x0E
#define RUCI_LEN_SET_RF_IDLE                    3
#define RUCI_NUM_SET_RF_IDLE                    3
#define RUCI_PARA_LEN_SET_RF_IDLE               0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfIdle[];
extern const uint8_t Ruci_ElmtNum_SetRfIdle[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RF_IDLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_SET_RF_IDLE;

// RUCI: SetDutyCycle ----------------------------------------------------------
#define RUCI_SET_DUTY_CYCLE                     RUCI_NUM_SET_DUTY_CYCLE, Ruci_ElmtType_SetDutyCycle, Ruci_ElmtNum_SetDutyCycle
#define RUCI_CODE_SET_DUTY_CYCLE                0x0F
#define RUCI_LEN_SET_DUTY_CYCLE                 11
#define RUCI_NUM_SET_DUTY_CYCLE                 5
#define RUCI_PARA_LEN_SET_DUTY_CYCLE            8
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetDutyCycle[];
extern const uint8_t Ruci_ElmtNum_SetDutyCycle[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_DUTY_CYCLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint32_t        RxOnTime;
    uint32_t        SleepTime;
} sRUCI_PARA_SET_DUTY_CYCLE;

// RUCI: GetRssi ---------------------------------------------------------------
#define RUCI_GET_RSSI                           RUCI_NUM_GET_RSSI, Ruci_ElmtType_GetRssi, Ruci_ElmtNum_GetRssi
#define RUCI_CODE_GET_RSSI                      0x12
#define RUCI_LEN_GET_RSSI                       3
#define RUCI_NUM_GET_RSSI                       3
#define RUCI_PARA_LEN_GET_RSSI                  0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetRssi[];
extern const uint8_t Ruci_ElmtNum_GetRssi[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_RSSI {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_GET_RSSI;

// RUCI: GetPhyStatus ----------------------------------------------------------
#define RUCI_GET_PHY_STATUS                     RUCI_NUM_GET_PHY_STATUS, Ruci_ElmtType_GetPhyStatus, Ruci_ElmtNum_GetPhyStatus
#define RUCI_CODE_GET_PHY_STATUS                0x14
#define RUCI_LEN_GET_PHY_STATUS                 3
#define RUCI_NUM_GET_PHY_STATUS                 3
#define RUCI_PARA_LEN_GET_PHY_STATUS            0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_GetPhyStatus[];
extern const uint8_t Ruci_ElmtNum_GetPhyStatus[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_GET_PHY_STATUS {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_GET_PHY_STATUS;

// RUCI: SetClockMode ----------------------------------------------------------
#define RUCI_SET_CLOCK_MODE                     RUCI_NUM_SET_CLOCK_MODE, Ruci_ElmtType_SetClockMode, Ruci_ElmtNum_SetClockMode
#define RUCI_CODE_SET_CLOCK_MODE                0x15
#define RUCI_LEN_SET_CLOCK_MODE                 6
#define RUCI_NUM_SET_CLOCK_MODE                 6
#define RUCI_PARA_LEN_SET_CLOCK_MODE            3
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetClockMode[];
extern const uint8_t Ruci_ElmtNum_SetClockMode[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_CLOCK_MODE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         ModemType;
    uint8_t         BandType;
    uint8_t         ClockMode;
} sRUCI_PARA_SET_CLOCK_MODE;

// RUCI: SetRfbAutoState -------------------------------------------------------
#define RUCI_SET_RFB_AUTO_STATE                 RUCI_NUM_SET_RFB_AUTO_STATE, Ruci_ElmtType_SetRfbAutoState, Ruci_ElmtNum_SetRfbAutoState
#define RUCI_CODE_SET_RFB_AUTO_STATE            0x16
#define RUCI_LEN_SET_RFB_AUTO_STATE             4
#define RUCI_NUM_SET_RFB_AUTO_STATE             4
#define RUCI_PARA_LEN_SET_RFB_AUTO_STATE        1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfbAutoState[];
extern const uint8_t Ruci_ElmtNum_SetRfbAutoState[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RFB_AUTO_STATE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         RxOnWhenIdle;
} sRUCI_PARA_SET_RFB_AUTO_STATE;

// RUCI: SetRfeSecurity --------------------------------------------------------
#define RUCI_SET_RFE_SECURITY                   RUCI_NUM_SET_RFE_SECURITY, Ruci_ElmtType_SetRfeSecurity, Ruci_ElmtNum_SetRfeSecurity
#define RUCI_CODE_SET_RFE_SECURITY              0x17
#define RUCI_LEN_SET_RFE_SECURITY               32
#define RUCI_NUM_SET_RFE_SECURITY               5
#define RUCI_PARA_LEN_SET_RFE_SECURITY          29
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfeSecurity[];
extern const uint8_t Ruci_ElmtNum_SetRfeSecurity[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RFE_SECURITY {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         SecKey[16];
    uint8_t         SecNonce[13];
} sRUCI_PARA_SET_RFE_SECURITY;

// RUCI: SetRfeTxEnable --------------------------------------------------------
#define RUCI_SET_RFE_TX_ENABLE                  RUCI_NUM_SET_RFE_TX_ENABLE, Ruci_ElmtType_SetRfeTxEnable, Ruci_ElmtNum_SetRfeTxEnable
#define RUCI_CODE_SET_RFE_TX_ENABLE             0x18
#define RUCI_LEN_SET_RFE_TX_ENABLE              23
#define RUCI_NUM_SET_RFE_TX_ENABLE              14
#define RUCI_PARA_LEN_SET_RFE_TX_ENABLE         20
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfeTxEnable[];
extern const uint8_t Ruci_ElmtNum_SetRfeTxEnable[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RFE_TX_ENABLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint16_t        PktInterval;
    uint16_t        PktLength;
    uint16_t        PktStepSize;
    uint16_t        PktCount;
    uint8_t         PktType;
    uint8_t         pktPhrType;
    uint8_t         AckEnable;
    uint32_t        AckTimeout;
    uint8_t         SecLevel;
    uint16_t        SecADataLen;
    uint16_t        SecMDataLen;
} sRUCI_PARA_SET_RFE_TX_ENABLE;

// RUCI: SetRfeTxDisable -------------------------------------------------------
#define RUCI_SET_RFE_TX_DISABLE                 RUCI_NUM_SET_RFE_TX_DISABLE, Ruci_ElmtType_SetRfeTxDisable, Ruci_ElmtNum_SetRfeTxDisable
#define RUCI_CODE_SET_RFE_TX_DISABLE            0x19
#define RUCI_LEN_SET_RFE_TX_DISABLE             3
#define RUCI_NUM_SET_RFE_TX_DISABLE             3
#define RUCI_PARA_LEN_SET_RFE_TX_DISABLE        0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfeTxDisable[];
extern const uint8_t Ruci_ElmtNum_SetRfeTxDisable[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RFE_TX_DISABLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_SET_RFE_TX_DISABLE;

// RUCI: SetRfeRxEnable --------------------------------------------------------
#define RUCI_SET_RFE_RX_ENABLE                  RUCI_NUM_SET_RFE_RX_ENABLE, Ruci_ElmtType_SetRfeRxEnable, Ruci_ElmtNum_SetRfeRxEnable
#define RUCI_CODE_SET_RFE_RX_ENABLE             0x1A
#define RUCI_LEN_SET_RFE_RX_ENABLE              19
#define RUCI_NUM_SET_RFE_RX_ENABLE              13
#define RUCI_PARA_LEN_SET_RFE_RX_ENABLE         16
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfeRxEnable[];
extern const uint8_t Ruci_ElmtNum_SetRfeRxEnable[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RFE_RX_ENABLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         PeriodicReportCycle;
    uint8_t         PktType;
    uint8_t         QueueType;
    uint8_t         RxType;
    uint32_t        RxTimeout;
    uint8_t         AckEnable;
    uint16_t        AckInterval;
    uint8_t         SecLevel;
    uint16_t        SecADataLen;
    uint16_t        SecMDataLen;
} sRUCI_PARA_SET_RFE_RX_ENABLE;

// RUCI: SetRfeRxDisable -------------------------------------------------------
#define RUCI_SET_RFE_RX_DISABLE                 RUCI_NUM_SET_RFE_RX_DISABLE, Ruci_ElmtType_SetRfeRxDisable, Ruci_ElmtNum_SetRfeRxDisable
#define RUCI_CODE_SET_RFE_RX_DISABLE            0x1B
#define RUCI_LEN_SET_RFE_RX_DISABLE             3
#define RUCI_NUM_SET_RFE_RX_DISABLE             3
#define RUCI_PARA_LEN_SET_RFE_RX_DISABLE        0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfeRxDisable[];
extern const uint8_t Ruci_ElmtNum_SetRfeRxDisable[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RFE_RX_DISABLE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_SET_RFE_RX_DISABLE;

// RUCI: SetRfeMode ------------------------------------------------------------
#define RUCI_SET_RFE_MODE                       RUCI_NUM_SET_RFE_MODE, Ruci_ElmtType_SetRfeMode, Ruci_ElmtNum_SetRfeMode
#define RUCI_CODE_SET_RFE_MODE                  0x1E
#define RUCI_LEN_SET_RFE_MODE                   4
#define RUCI_NUM_SET_RFE_MODE                   4
#define RUCI_PARA_LEN_SET_RFE_MODE              1
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetRfeMode[];
extern const uint8_t Ruci_ElmtNum_SetRfeMode[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_RFE_MODE {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
    uint8_t         Mode;
} sRUCI_PARA_SET_RFE_MODE;

#pragma pack(pop)
#endif /* RUCI_ENABLE_PCI */
#endif /* _RUCI_PCI_COMMON_CMD_H */
