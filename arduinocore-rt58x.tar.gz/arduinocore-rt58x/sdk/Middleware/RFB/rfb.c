/**
 * @file rfb.c
 * @author
 * @date
 * @brief To control rfb
 *
 * More detailed description can go here
 *
 *
 * @see http://
 */
/**************************************************************************************************
*    INCLUDES
*************************************************************************************************/
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "radio.h"
#include "rfb.h"
#include "rfb_port.h"


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/


/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/

#if (defined RFB_ZIGBEE_ENABLED && RFB_ZIGBEE_ENABLED == 1)
/* Register Rfb control Apis*/
rfb_zb_ctrl_t const rfb_zb_ctrl = {
    rfb_port_zb_init,
    rfb_port_frequency_set,
    rfb_port_zb_is_channel_free,
    rfb_port_data_send,
    rfb_port_tx_continuous_wave_set,
    rfb_port_rssi_read,
    rfb_port_15p4_address_filter_set,
    rfb_port_15p4_mac_pib_set,
    rfb_port_15p4_phy_pib_set,
    rfb_port_15p4_auto_ack_set,
    rfb_port_15p4_pending_bit_set,
    rfb_port_auto_state_set,
    rfb_port_version_get,
};
#endif

#if (defined RFB_WISUN_ENABLED && RFB_WISUN_ENABLED == 1)
/* Register Rfb control Apis*/
rfb_wisun_ctrl_t const rfb_ctrl = {
    rfb_port_wisun_init,
    rfb_port_modem_set,
    rfb_port_frequency_set,
    rfb_port_wisun_is_channel_free,
    rfb_port_wisun_rx_config_set,
    rfb_port_wisun_tx_config_set,
    rfb_port_data_send,
    rfb_port_sleep_set,
    rfb_port_idle_set,
    rfb_port_rx_start,
    rfb_port_tx_continuous_wave_set,
    rfb_port_rssi_read,
    rfb_port_version_get
};
#endif

/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/
#if (defined RFB_ZIGBEE_ENABLED && RFB_ZIGBEE_ENABLED == 1)
rfb_zb_ctrl_t *rfb_zb_init(void)
{
    return (rfb_zb_ctrl_t *)&rfb_zb_ctrl;
}
#endif

#if (defined RFB_WISUN_ENABLED && RFB_WISUN_ENABLED == 1)
rfb_wisun_ctrl_t *rfb_wisun_init(void)
{
    return (rfb_wisun_ctrl_t *)&rfb_ctrl;
}
#endif

