
/** @file util_string.h
 *
 * @license
 * @description
 */

#ifndef __util_string_H_wvsMcgCi_lk2Z_HajD_syQf_u1Yfwot7R8PD__
#define __util_string_H_wvsMcgCi_lk2Z_HajD_syQf_u1Yfwot7R8PD__

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup string handler api
 *  @{
 */

#include <stdbool.h>
//=============================================================================
//                  Constant Definition
//=============================================================================

//=============================================================================
//                  Macro Definition
//=============================================================================

//=============================================================================
//                  Structure Definition
//=============================================================================

//=============================================================================
//                  Global Data Definition
//=============================================================================

//=============================================================================
//                  Private Function Definition
//=============================================================================

//=============================================================================
//                  Public Function Definition
//=============================================================================
long utility_strtol(const char *str, char **ep);

// str to unsigned long
unsigned long utility_strtoul(const char *str, char **ep);

// str to hex
unsigned long utility_strtox(const char *str, char **ep);

// long to string
void utility_ltoa(char *a, unsigned long *len, long l, bool w_sign);

// long to string
void utility_ultoa(char *a, unsigned long *len, unsigned long u);

// hex to string
void utility_xtoa(char *a, unsigned long *len, unsigned long x, bool capitalized);

long utility_strlen(const char *s);

void utility_ftoa(char *a, unsigned long *len, double f, unsigned long frc_precision);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif
