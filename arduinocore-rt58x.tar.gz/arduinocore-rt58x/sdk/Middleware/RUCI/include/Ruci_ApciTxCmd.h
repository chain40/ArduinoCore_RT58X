/******************************************************************************
*
* @File			Ruci_ApciTxCmd.h
* @Version
* $Revision: 4157
* $Date: 2021-12-27
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef _RUCI_APCI_TX_CMD_H
#define _RUCI_APCI_TX_CMD_H

#include "Ruci_Head.h"

#if (RUCI_ENABLE_APCI)

/******************************************************************************
* DEFINES
*****************************************************************************/

#pragma pack(push)
#pragma pack(1)
#define RUCI_APCI_TX_CMD_HEADER 0x21

// RUCI: SetTxOn ---------------------------------------------------------------
#define RUCI_SET_TX_ON                          RUCI_NUM_SET_TX_ON, Ruci_ElmtType_SetTxOn, Ruci_ElmtNum_SetTxOn
#define RUCI_CODE_SET_TX_ON                     0x01
#define RUCI_LEN_SET_TX_ON                      3
#define RUCI_NUM_SET_TX_ON                      3
#define RUCI_PARA_LEN_SET_TX_ON                 0
#if (RUCI_ENDIAN_INVERSE)
extern const uint8_t Ruci_ElmtType_SetTxOn[];
extern const uint8_t Ruci_ElmtNum_SetTxOn[];
#endif /* RUCI_ENDIAN_INVERSE */
typedef struct RUCI_PARA_SET_TX_ON {
    sRUCI_HEAD      RuciHeader;
    uint8_t         Subheader;
    uint8_t         Length;
} sRUCI_PARA_SET_TX_ON;

#pragma pack(pop)
#endif /* RUCI_ENABLE_APCI */
#endif /* _RUCI_APCI_TX_CMD_H */
