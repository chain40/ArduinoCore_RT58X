/*************************************************************************************************/
/*!
 *  \file   fcs.h
 *
 *  \brief  FCS utilities (3GPP TS 27.010).
 *
 */
/*************************************************************************************************/
#ifndef FCS_H
#define FCS_H

#ifdef __cplusplus
extern "C" {
#endif
#include <stdint.h>
/*************************************************************************************************/
/*!
 *  \brief  Calculate the FCS of the given buffer.
 *
 *  \param  len      Length of the buffer.
 *  \param  pBuf     Buffer to compute the CRC.
 *
 *  \return FCS value.
 */
/*************************************************************************************************/
uint8_t FcsCalc(uint32_t len, const uint8_t *pBuf);

/*************************************************************************************************/
/*!
 *  \brief  Computes resultant CRC by appending one byte.
 *
 *  \param  pFcs     CRC value on which to append the byte.
 *  \param  byte     Byte to be added to CRC computation.
 *
 *  \return FCS value.
 */
/*************************************************************************************************/
void FcsAddByte(uint8_t *pFcs, uint8_t byte);

#ifdef __cplusplus
};
#endif

#endif /* FCS_H */
