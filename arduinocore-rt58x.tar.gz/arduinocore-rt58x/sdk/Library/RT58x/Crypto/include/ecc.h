/**************************************************************************//**
 * @file     ecc.h
 * @version
 * @brief    ECC driver header file
 *
 * @copyright
 ******************************************************************************/
 
 
#ifndef ___ECC_H__
#define ___ECC_H__

#ifdef __cplusplus
extern "C"
{
#endif

/** @addtogroup Standard_Driver Standard Driver
  @{
*/

/** @addtogroup ECC_Driver  ECC Driver
  @{
*/

/** @addtogroup ECC_EXPORTED_CONSTANTS ECC Exported Constants
  @{
*/

/*The following define in size of "uint32_t" */

/*secp192r1 curve is 192 bytes, 6*uint32_t = 192 */
#define secp192r1_op_num      6             /*!< SECP192R1 key size is 6*sizeof(uint32_t)  \hideinitializer */

/*secp256r1 curve is 256 bytes, 8*uint32_t = 256 */
#define secp256r1_op_num      8             /*!< SECP256R1 key size is 8*sizeof(uint32_t)  \hideinitializer */

/*curve X25519/C25519 is 256 bytes data. 8*uint32_t = 256 */
#define C25519_Length         8             /*!< X25519/C25519 key size is 8*sizeof(uint32_t)  \hideinitializer */

/*@}*/ /* end of group ECC_EXPORTED_CONSTANTS */


/** @addtogroup ECC_EXPORTED_FUNCTIONS ECC Exported Functions
  @{
*/


#if MODULE_ENABLE(CRYPTO_SECP192R1_ENABLE)

/**
 * @brief Set Crypto Engine to load ECC SECP192R1 curve algorithm.
 *
 * @param[in]  None
 *
 * @details  Crypto Engine needs to load crypto algorithm before doing crypto operation.
 *            This initialize function must be call every time before calling gfp_point_p192_mult.
 *
 */
extern uint32_t gfp_ecc_curve_p192_init(void);

/**
 * @brief   Use Crypto Engine to caculate ECC point K*G based on SECP192R1 curve,
 *           G is the point on curve and K is a big number.
 *
 * @param[out]  p_result_x   output buffer for the point x-coordinate of K*G
 * @param[out]  p_result_y   output buffer for the point y-coordinate of K*G
 * @param[in]   target_x     input buffer for the point Gx
 * @param[in]   target_y     input buffer for the point Gy
 * @param[in]   target_k     the private key.
 *
 * @details   Notice: ALL buffer data is little endian format.
 *
 */
    
extern uint32_t gfp_point_p192_mult(
    uint32_t *p_result_x, 
    uint32_t *p_result_y, 
    uint32_t *target_x, 
    uint32_t *target_y, 
    uint32_t *target_k
);

#endif

#if  MODULE_ENABLE(CRYPTO_SECP256R1_ENABLE)

/**
 * @brief Set Crypto Engine to load ECC SECP256R1 curve algorithm.
 *
 * @param[in]  None
 *
 * @details  Crypto Engine needs to load crypto algorithm before doing crypto operation.
 *            This initialize function must be call every time before calling gfp_point_p256_mult.
 *
 */
extern uint32_t gfp_ecc_curve_p256_init(void);

/**
 * @brief   Use Crypto Engine to caculate ECC point K*G based on SECP256R1 curve,
 *           G is the point on curve and K is a big number.
 *
 * @param[out]  p_result_x   output buffer for the point x-coordinate of K*G
 * @param[out]  p_result_y   output buffer for the point y-coordinate of K*G
 * @param[in]   target_x     input buffer for the point Gx
 * @param[in]   target_y     input buffer for the point Gy
 * @param[in]   target_k     the private key.
 *
 * @details   Notice: ALL buffer data is little endian format.
 *
 */

extern uint32_t gfp_point_p256_mult(
    uint32_t *p_result_x, 
    uint32_t *p_result_y, 
    uint32_t *target_x, 
    uint32_t *target_y, 
    uint32_t *target_k
);


/**
 * @brief Set Crypto Engine to load ECDSA Verify algorithm based on ECC SECP256R1 curve.
 *
 * @param[in]  None
 *
 * @details  Crypto Engine needs to load crypto algorithm before doing crypto operation.
 *            This initialize function must be called before calling gfp_ecdsa_p256_verify.
 *            
 */

extern void gfp_ecdsa_p256_verify_init(void);

/**
 * @brief   Use Crypto Engine to verify ECDSA result based on SECP256R1 curve,
 *           
 * @param[out]  p_result_x   ouput buffer for the caculate result.
 * @param[in]   r            input buffer for the signature, the lower 32 bytes.
 * @param[in]   s            input buffer for the signature, the higher 32 bytes.
 * @param[in]   h            input buffer for the hash data, 32 bytes. 
 * @param[in]   public_x     input buffer for the public key x, 32 bytes.
 * @param[in]   public_y     input buffer for the public key y, 32 bytes.
 *
 * @retval
 *             return 0  for verification fail
 *             return 1  for verification success.
 *
 * @details   Notice: ALL buffer data is little endian format.
 *
 */
 
extern uint32_t gfp_ecdsa_p256_verify(uint32_t *p_result_x, uint32_t *r, uint32_t *s, uint32_t *h, uint32_t *public_x, uint32_t *public_y);


#endif

#if MODULE_ENABLE(CRYPTO_SECT163R2_ENABLE) 
/**
 * @brief Set Crypto Engine to load ECC SECP163R2 curve algorithm.
 *
 * @param[in]  None
 *
 * @details  Crypto Engine needs to load crypto algorithm before doing crypto operation.
 *            This initialize function must be call every time before calling gfp_point_b163_mult.
 *
 */
extern uint32_t gf2m_ecc_curve_b163_init(void);

/**
 * @brief   Use Crypto Engine to caculate ECC point K*G based on SECT163R2 curve,
 *           G is the point on curve and K is a big number.
 *
 * @param[out]  p_result_x   output buffer for the point x-coordinate of K*G
 * @param[out]  p_result_y   output buffer for the point y-coordinate of K*G
 * @param[in]   target_x     input buffer for the point Gx
 * @param[in]   target_y     input buffer for the point Gy
 * @param[in]   target_k     the private key.
 *
 * @details   Notice: ALL buffer data is little endian format.
 *
 */
extern void gf2m_point_b163_mult(
    uint32_t *p_result_x, 
    uint32_t *p_result_y, 
    uint32_t *target_x, 
    uint32_t *target_y, 
    uint32_t *target_k
);

#endif

#if MODULE_ENABLE(CRYPTO_C25519_ENABLE)

/**
 * @brief Set Crypto Engine to load ECC Curve25519 algorithm.
 *
 * @param[in]  None
 *
 * @details  Crypto Engine needs to load crypto algorithm before doing crypto operation.
 *            
 *
 */

extern void curve_c25519_init(void);

/**
 * @brief   Use Crypto Engine to caculate ECC point K*G based on Curve25519,
 *           G is the point on curve and K is a big number.
 *
 * @param[in]   blind_zr     a random number buffer for against side-channel attacks
 * @param[out]  public_key   output buffer for the point x-coordinate of K*G
 * @param[in]   secret_key   the private key.
 * @param[in]   base_point   input buffer for the point x-coordinate of G
 * 
 * @details  Notice: ALL buffer data is little endian format.
 *            Remark:  blind_zr is random 32 bytes, it used to add entropy, that outside can not guess
 *            key by "current"  or "caculate time". It can be NULL for using default blind pattern.
 *
 *
 */
 
extern void curve25519_point_mul(uint32_t *blind_zr, uint32_t *public_key, uint32_t *secret_key, uint32_t *base_point);

/**
 * @brief Release Crypto Engine for ECC Curve25519 algorithm.
 *
 * @param[in]  None
 *
 * @details  In multi-tasking OS, it should avoid two task request crypto engine at the same time.
 *            So it needs semaphore to control the access request.
 *            The semaphore implemented depends on operating system.
 *            Call this function when system finishs curve25516 operations.
 * 
 */

extern uint32_t curve25519_release(void);

#endif


/*@}*/ /* end of group ECC_EXPORTED_FUNCTIONS */

/*@}*/ /* end of group ECC_Driver */

/*@}*/ /* end of group Standard_Driver */

#ifdef __cplusplus
}
#endif

#endif
