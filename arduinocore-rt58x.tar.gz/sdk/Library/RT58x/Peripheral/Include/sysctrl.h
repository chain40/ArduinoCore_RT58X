/**************************************************************************//**
 * @file     sysctrl.h
 * @version
 * @brief    SYS CONTROL driver header file
 *
 * @copyright
 ******************************************************************************/
#ifndef ___SYSCTRL_H__
#define ___SYSCTRL_H__

#ifdef __cplusplus
extern "C"
{
#endif

#define MAP_BASE         (SYSCTRL_BASE + 0x10)
#define PULLOPT_BASE     (SYSCTRL_BASE + 0x20)
#define DRV_BASE         (SYSCTRL_BASE + 0x30)
#define OD_BASE          (SYSCTRL_BASE + 0x38)


/*Define AHB SYSTEM CLOCK mode*/
#define SYS_CLK_32MHZ    0
#define SYS_CLK_48MHZ    1
#define SYS_CLK_64MHZ    2

/*Because compiler code optimize, we should set PLL_WAIT_PERIOD as 4N */
#define PLL_WAIT_PERIOD      800


/* NOTICE: We don't consider race condition issue here.
 * So System after power up, it should initialize the pin mode ASAP, and don't change anymore.
 *
 */
#define MODE_GPIO            0
#define MODE_QSPI0           1
#define MODE_I2C             4
#define MODE_UART            6

#define MODE_I2S             4
#define MODE_PWM0            1
#define MODE_PWM1            2
#define MODE_PWM2            3
#define MODE_PWM3            5
#define MODE_PWM4            7

#define MODE_QSPI1           5

#define MODE_EXT32K          5

/*NOTICE: The following setting only in GPIO0~GPIO3*/
#define MODE_QSPI0_CSN1       2
#define MODE_QSPI0_CSN2       3
#define MODE_QSPI0_CSN3       6

/*Driving through setting mode*/
#define MODE_PULL_NONE         0
#define MODE_PULLDOWN_10K      1
#define MODE_PULLDOWN_100K     2
#define MODE_PULLDOWN_1M       3
#define MODE_PULLUP_10K        5
#define MODE_PULLUP_100K       6
#define MODE_PULLUP_1M         7

/*Define used for pin_set_pullopt */
#define PULL_NONE           0
#define PULL_DOWN_10K       1
#define PULL_DOWN_100K      2
#define PULL_DOWN_1M        3
#define PULL_UP_10K         5
#define PULL_UP_100K        6
#define PULL_UP_1M          7

/*Define used for pin_set_drvopt */
#define DRV_4MA             0
#define DRV_10MA            1
#define DRV_14MA            2
#define DRV_20MA            3

/*Define IC chip id  and chip revision information*/

#define IC_CHIP_ID_MASK_SHIFT      8
#define IC_CHIP_ID_MASK           (0xFF<<IC_CHIP_ID_MASK_SHIFT)

#define IC_RT58X                  (0x70<<IC_CHIP_ID_MASK_SHIFT)

#define IC_CHIP_REVISION_MASK_SHIFT      4
#define IC_CHIP_REVISION_MASK            (0xF<<IC_CHIP_REVISION_MASK_SHIFT)

#define IC_CHIP_REVISION_MPA             (1<<IC_CHIP_REVISION_MASK_SHIFT)
#define IC_CHIP_REVISION_MPB             (2<<IC_CHIP_REVISION_MASK_SHIFT)


extern uint32_t pin_get_mode(uint32_t pin_number);

extern void pin_set_mode(uint32_t pin_number, uint32_t mode);

extern void enable_perclk(uint32_t clock);

extern void disable_perclk(uint32_t clock);

extern void set_sleep_option(uint32_t hclk_frozen_mode, uint32_t rtc_ds_wakeup_enable_mode);

/* Set pin pull option. */
extern void pin_set_pullopt(uint32_t pin_number, uint32_t mode);

/* Set pin driver mode*/
extern void pin_set_drvopt(uint32_t pin_number, uint32_t mode);

/*opendrain pin is for I2C used.*/
extern void enable_pin_opendrain(uint32_t pin_number);

extern void disable_pin_opendrain(uint32_t pin_number);

/*
 * Change CPU AHB CLOCK, 
 *      return STATUS_SUCCESS(0) for change success.
 *      return STATUS_ERROR      for change fail.
 * 
 */
extern uint32_t change_ahb_system_clk(uint32_t clk_mode);

/*
 * Get CPU AHB CLOCK, 
 *      return SYS_CLK_32MHZ      for CPU AHB 32MHz clock.
 *      return SYS_CLK_48MHZ      for CPU AHB 48MHz clock.
 *      return SYS_CLK_64MHZ      for CPU AHB 64MHz clock.
 * 
 */
extern uint32_t get_ahb_system_clk(void);

/*
 * Select Slow clock source.
 * Available mode:
 *         SLOW_CLOCK_INTERNAL   --- default value. 
 *                  If system don't call this function, then slow clock source is from internal RCO by default.
 *         
 *          SLOW_CLOCK_FROM_GPIO ---
 *                 If system set this mode, system should use an external 32K source from GPIO.
 *                
 *
 */
extern void set_slow_clock_source(uint32_t mode);

/*
 * generate a 32bits random number.
 * Please notice: this function is block mode, it will block about 4ms ~ 6ms.
 * If you want to use non-block mode, maybe you should use interrupt mode.
 */
extern uint32_t get_random_number(void);

/**
 * @brief sys_set_retention_reg. Use to save some retention value.
 *
 * @param index: The index for which scratchpad register to save
 *                It should be 0~7.
 * @param value: register value
 *
 */

__STATIC_INLINE void sys_set_retention_reg(uint32_t index, uint32_t value)
{
    if(index<8)
        outp32(((SYSCTRL_BASE+SYS_SCRATCH_OFFSET) + (index <<2)), value);
}

/**
 * @brief sys_get_retention_reg. Use to get some retention value.
 *
 * @param index: The index for which scratchpad register to get
 *                It should be 0~7.
 * @param *value: the address of return value.
 *
 */

__STATIC_INLINE void sys_get_retention_reg(uint32_t index, uint32_t *value)
{
    if(index<8)
        *value =  inp32((SYSCTRL_BASE+SYS_SCRATCH_OFFSET)+(index <<2));
    else
        *value = 0;         /*wrong index*/
}

/*
 *
 */
__STATIC_INLINE void set_lowpower_control(uint32_t value)
{
    SYSCTRL->SYS_LOWPOWER_CTRL = value;
}

__STATIC_INLINE uint32_t get_lowpower_control(void)
{
    return ((uint32_t)(SYSCTRL->SYS_LOWPOWER_CTRL));
}

__STATIC_INLINE uint32_t get_clk_control(void)
{
    return ((uint32_t)(SYSCTRL->SYS_CLK_CTRL));
}


__STATIC_INLINE void set_deepsleep_wakeup_pin(uint32_t value)
{
     SYSCTRL->DEEPSLEEP_WAKEUP = value;
}

__STATIC_INLINE void set_deepsleep_wakeup_invert(uint32_t value)
{
    SYSCTRL->DEEPSLEEP_INV = value;
}

__STATIC_INLINE void set_sram_shutdown_normal(uint32_t value)
{
    SYSCTRL->SRAM_SD_NM = value;
}

__STATIC_INLINE void set_sram_shutdown_sleep(uint32_t value)
{
    SYSCTRL->SRAM_SD_SL = value;
}


/**
 * @brief Check IC version
 *
 * @param  None
 *
 * @retval    IC version
 *
 * @details   Return IC version information
 *             Bit7 ~ Bit4 is chip_revision
 *             Bit15 ~ Bit8 is chip_id
 */

/*check Flash command Finish*/
__STATIC_INLINE uint32_t get_chip_version(void)
{
    return ((uint32_t)(SYSCTRL->CHIP_INFO));
}


#ifdef __cplusplus
}
#endif

#endif
