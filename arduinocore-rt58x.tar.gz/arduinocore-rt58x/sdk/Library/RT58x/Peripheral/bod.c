/** @file
 *
 * @brief BOD driver file.
 *
 */

/**
 * @defgroup BOD Group
 * @{
 * @brief    BOD group.
 */

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/
#include "cm3_mcu.h"


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/


/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/
static bod_isr_handler_t   bod_reg_handler = NULL;


/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/


/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/

/**
 * @brief BOD interrupt handler
 * @details Clear the BOD interrupt status and handle the BOD interrupt routine
 * @param None
 * @return None
 */
void bod_handler(void)
{
    if (BOD_INT_STATUS_GET()) {
        BOD_INT_CLEAR();

        if (BOD_INT_STATUS_GET()) {
            ASSERT();
        }
			
        if(bod_reg_handler != NULL) {
            bod_reg_handler();
        }
    }
    return;
}


/**
 * @brief BOD interrupt service routine callback for user application.
 * @param[in] bod_int_callback BOD interrupt callback handler
 * @return None
 */
void bod_register_int_callback(bod_isr_handler_t bod_int_callback)
{
    bod_reg_handler = bod_int_callback;

    return;
}


/**
 * @brief Enable the specified BOD interrupts
 * @param[in] int_mask Specifies the BOD interrupt sources to be enabled
 * @return None
 */
void bod_int_enable(void)
{
    BOD_INT_CLEAR();
    BOD_INT_ENABLE();
    NVIC_EnableIRQ((IRQn_Type)(Bod_IRQn));

    return;
}


/**
 * @brief Disable all BOD interrupt(s)
 * @param None
 * @return None
 */
void bod_int_disable(void)
{
    NVIC_DisableIRQ((IRQn_Type)(Bod_IRQn));
    BOD_INT_DISABLE();
    BOD_INT_CLEAR();

    return;
}


uint32_t bod_init(bod_config_t *p_config, bod_isr_handler_t bod_int_callback)
{
    if (p_config == NULL) {
        return STATUS_INVALID_PARAM;
    }

    BOD_INT_POL(p_config->bod_int_pol);            /*Set BOD interrupt polarity*/
    BOD_RISING_V(p_config->bod_rising_v);          /*Set BOD rising voltage threshold*/
    BOD_FALLING_V(p_config->bod_falling_v);        /*Set BOD rising voltage threshold*/

    if (bod_int_callback != NULL) {
        bod_register_int_callback(bod_int_callback);
    }
    bod_int_enable();

    BOD_NM_ENABLE();

    return STATUS_SUCCESS;
}


/** @} */
