/******************************************************************************
*
* @File			Ruci.h
* @Version
* $Revision: 4235
* $Date: 2022-02-07
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
******************************************************************************/
#ifndef RUCI_H
#define RUCI_H

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_Head.h"
#include "Ruci_PciCommonCmd.h"
#include "Ruci_PciFskCmd.h"
#include "Ruci_PciBleCmd.h"
#include "Ruci_Pci15p4MacCmd.h"
#include "Ruci_PciOqpskCmd.h"
#include "Ruci_PciSlinkCmd.h"
#include "Ruci_PciEvent.h"
#include "Ruci_PciData.h"
#include "Ruci_ApciRfCmd.h"
#include "Ruci_ApciTxCmd.h"
#include "Ruci_ApciRxCmd.h"
#include "Ruci_CmnSysCmd.h"
#include "Ruci_CmnHalCmd.h"
#include "Ruci_CmnEvent.h"
#include "Ruci_HostCmd.h"
#include "Ruci_HostEvent.h"

/*****************************************************************************
* DEFINES
******************************************************************************/
#define RUCI_VERSION  (4235) 

#if (RUCI_ENDIAN_INVERSE)
    #define RUCI_ENDIAN_CONVERT(pData, para)        RUCI_endianConvert(pData, para)
#else
    #define RUCI_ENDIAN_CONVERT(pData, para)
#endif


/*****************************************************************************
* GLOBAL FUNCTIONS
******************************************************************************/
#if (RUCI_ENDIAN_INVERSE)
void RUCI_endianConvert(
    uint8_t         *pDataIn,
    uint8_t         paraNum,
    const uint8_t   *pTypeMapIn,
    const uint8_t   *pElemNumMapIn
);
#endif

/*****************************************************************************
* PCI COMMON CMD
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RF_FREQUENCY) */
#define SET_RUCI_PARA_COMMON_RF_CHANNEL(msg, channel)                                                               \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RF_FREQUENCY *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                       \
            ((sRUCI_PARA_SET_RF_FREQUENCY *)msg)->Subheader = RUCI_CODE_SET_RF_FREQUENCY;                           \
            ((sRUCI_PARA_SET_RF_FREQUENCY *)msg)->Length = RUCI_PARA_LEN_SET_RF_FREQUENCY;                          \
            ((sRUCI_PARA_SET_RF_FREQUENCY *)msg)->RfFrequency = channel;                                            \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RX_ENABLE) */
#define SET_RUCI_PARA_COMMON_RX_ENABLE(msg, rx_time)                                                                \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RX_ENABLE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                          \
            ((sRUCI_PARA_SET_RX_ENABLE *)msg)->Subheader = RUCI_CODE_SET_RX_ENABLE;                                 \
            ((sRUCI_PARA_SET_RX_ENABLE *)msg)->Length = RUCI_PARA_LEN_SET_RX_ENABLE;                                \
            ((sRUCI_PARA_SET_RX_ENABLE *)msg)->RxOnTime = rx_time;                                                  \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_SINGLE_TONE_MODE) */
#define SET_RUCI_PARA_COMMON_SINGLE_TONE(msg, mode)                                                                 \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_SINGLE_TONE_MODE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                   \
            ((sRUCI_PARA_SET_SINGLE_TONE_MODE *)msg)->Subheader = RUCI_CODE_SET_SINGLE_TONE_MODE;                   \
            ((sRUCI_PARA_SET_SINGLE_TONE_MODE *)msg)->Length = RUCI_PARA_LEN_SET_SINGLE_TONE_MODE;                  \
            ((sRUCI_PARA_SET_SINGLE_TONE_MODE *)msg)->StMode = mode;                                                \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_GET_CRC_COUNT) */
#define SET_RUCI_PARA_COMMON_GET_CRC_COUNT(msg)                                                                     \
        do{                                                                                                         \
            ((sRUCI_PARA_GET_CRC_COUNT *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                          \
            ((sRUCI_PARA_GET_CRC_COUNT *)msg)->Subheader = RUCI_CODE_GET_CRC_COUNT;                                 \
            ((sRUCI_PARA_GET_CRC_COUNT *)msg)->Length = RUCI_PARA_LEN_GET_CRC_COUNT;                                \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RF_SLEEP) */
#define SET_RUCI_PARA_COMMON_RF_SLEEP(msg, is_enable)                                                               \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RF_SLEEP *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                           \
            ((sRUCI_PARA_SET_RF_SLEEP *)msg)->Subheader = RUCI_CODE_SET_RF_SLEEP;                                   \
            ((sRUCI_PARA_SET_RF_SLEEP *)msg)->Length = RUCI_PARA_LEN_SET_RF_SLEEP;                                  \
            ((sRUCI_PARA_SET_RF_SLEEP *)msg)->EnableFlag = is_enable;                                               \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RF_IDLE) */
#define SET_RUCI_PARA_COMMON_RF_IDLE(msg)                                                                           \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RF_IDLE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                            \
            ((sRUCI_PARA_SET_RF_IDLE *)msg)->Subheader = RUCI_CODE_SET_RF_IDLE;                                     \
            ((sRUCI_PARA_SET_RF_IDLE *)msg)->Length = RUCI_PARA_LEN_SET_RF_IDLE;                                    \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_DUTY_CYCLE) */
#define SET_RUCI_PARA_COMMON_DUTY_CYCLE(msg, rx_on_time, sleep_time)                                                \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_DUTY_CYCLE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                         \
            ((sRUCI_PARA_SET_DUTY_CYCLE *)msg)->Subheader = RUCI_CODE_SET_DUTY_CYCLE;                               \
            ((sRUCI_PARA_SET_DUTY_CYCLE *)msg)->Length = RUCI_PARA_LEN_SET_DUTY_CYCLE;                              \
            ((sRUCI_PARA_SET_DUTY_CYCLE *)msg)->RxOnTime = rx_on_time;                                              \
            ((sRUCI_PARA_SET_DUTY_CYCLE *)msg)->SleepTime = sleep_time;                                             \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_GET_RSSI) */
#define SET_RUCI_PARA_COMMON_GET_RSSI(msg)                                                                          \
        do{                                                                                                         \
            ((sRUCI_PARA_GET_RSSI *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                               \
            ((sRUCI_PARA_GET_RSSI *)msg)->Subheader = RUCI_CODE_GET_RSSI;                                           \
            ((sRUCI_PARA_GET_RSSI *)msg)->Length = RUCI_PARA_LEN_GET_RSSI;                                          \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_GET_PHY_STATUS) */
#define SET_RUCI_PARA_COMMON_GET_PHY_STATUS(msg)                                                                    \
        do{                                                                                                         \
            ((sRUCI_PARA_GET_PHY_STATUS *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                         \
            ((sRUCI_PARA_GET_PHY_STATUS *)msg)->Subheader = RUCI_CODE_GET_PHY_STATUS;                               \
            ((sRUCI_PARA_GET_PHY_STATUS *)msg)->Length = RUCI_PARA_LEN_GET_PHY_STATUS;                              \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_CLOCK_MODE) */
#define SET_RUCI_PARA_COMMON_CLOCK_MODE(msg, modem_type, band_type, clock_mode)                                     \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_CLOCK_MODE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                         \
            ((sRUCI_PARA_SET_CLOCK_MODE *)msg)->Subheader = RUCI_CODE_SET_CLOCK_MODE;                               \
            ((sRUCI_PARA_SET_CLOCK_MODE *)msg)->Length = RUCI_PARA_LEN_SET_CLOCK_MODE;                              \
            ((sRUCI_PARA_SET_CLOCK_MODE *)msg)->ModemType = modem_type;                                             \
            ((sRUCI_PARA_SET_CLOCK_MODE *)msg)->BandType = band_type;                                               \
            ((sRUCI_PARA_SET_CLOCK_MODE *)msg)->ClockMode = clock_mode;                                             \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RFB_AUTO_STATE) */
#define SET_RUCI_PARA_COMMON_RFB_AUTO_STATE(msg, is_rx_on_idle)                                                     \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RFB_AUTO_STATE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                     \
            ((sRUCI_PARA_SET_RFB_AUTO_STATE *)msg)->Subheader = RUCI_CODE_SET_RFB_AUTO_STATE;                       \
            ((sRUCI_PARA_SET_RFB_AUTO_STATE *)msg)->Length = RUCI_PARA_LEN_SET_RFB_AUTO_STATE;                      \
            ((sRUCI_PARA_SET_RFB_AUTO_STATE *)msg)->RxOnWhenIdle = is_rx_on_idle;                                   \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RFE_SECURITY) */
#define SET_RUCI_PARA_COMMON_RFE_SECURITY(msg)                                                                      \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RFE_SECURITY *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                       \
            ((sRUCI_PARA_SET_RFE_SECURITY *)msg)->Subheader = RUCI_CODE_SET_RFE_SECURITY;                           \
            ((sRUCI_PARA_SET_RFE_SECURITY *)msg)->Length = RUCI_PARA_LEN_SET_RFE_SECURITY;                          \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RFE_TX_ENABLE) */
#define SET_RUCI_PARA_COMMON_RFE_TX_EN(msg, pkt_interval, pkt_len, pkt_step_size, pkt_count, pkt_type,              \
                                            pkt_phy_type, ack_enable, ack_timeout, sec_level,                       \
                                            sec_a_data_len, sec_m_data_len)                                         \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                      \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->Subheader = RUCI_CODE_SET_RFE_TX_ENABLE;                         \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->Length = RUCI_PARA_LEN_SET_RFE_TX_ENABLE;                        \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->PktInterval = pkt_interval;                                      \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->PktLength = pkt_len;                                             \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->PktStepSize = pkt_step_size;                                     \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->PktCount = pkt_count;                                            \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->PktType = pkt_type;                                              \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->pktPhrType = pkt_phy_type;                                       \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->AckEnable = ack_enable;                                          \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->AckTimeout = ack_timeout;                                        \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->SecLevel = sec_level;                                            \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->SecADataLen = sec_a_data_len;                                    \
            ((sRUCI_PARA_SET_RFE_TX_ENABLE *)msg)->SecMDataLen = sec_m_data_len;                                    \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RFE_TX_DISABLE) */
#define SET_RUCI_PARA_COMMON_RFE_TX_DISABLE(msg)                                                                    \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RFE_TX_DISABLE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                     \
            ((sRUCI_PARA_SET_RFE_TX_DISABLE *)msg)->Subheader = RUCI_CODE_SET_RFE_TX_DISABLE;                       \
            ((sRUCI_PARA_SET_RFE_TX_DISABLE *)msg)->Length = RUCI_PARA_LEN_SET_RFE_TX_DISABLE;                      \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RFE_RX_ENABLE) */
#define SET_RUCI_PARA_COMMON_RFE_RX_EN(msg, report_cycle, pkt_type, queue_type, rx_type,                            \
                                            rx_timeout, ack_enable, ack_interval, sec_level,                        \
                                            sec_a_data_len, sec_m_data_len)                                         \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                      \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->Subheader = RUCI_CODE_SET_RFE_RX_ENABLE;                         \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->Length = RUCI_PARA_LEN_SET_RFE_RX_ENABLE;                        \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->PeriodicReportCycle = report_cycle;                              \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->PktType = pkt_type;                                              \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->QueueType = queue_type;                                          \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->RxType = rx_type;                                                \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->RxTimeout = rx_timeout;                                          \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->AckEnable = ack_enable;                                          \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->AckInterval = ack_interval;                                      \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->SecLevel = sec_level;                                            \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->SecADataLen = sec_a_data_len;                                    \
            ((sRUCI_PARA_SET_RFE_RX_ENABLE *)msg)->SecMDataLen = sec_m_data_len;                                    \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RFE_RX_DISABLE) */
#define SET_RUCI_PARA_COMMON_RFE_RX_DISABLE(msg)                                                                    \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RFE_RX_DISABLE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                     \
            ((sRUCI_PARA_SET_RFE_RX_DISABLE *)msg)->Subheader = RUCI_CODE_SET_RFE_RX_DISABLE;                       \
            ((sRUCI_PARA_SET_RFE_RX_DISABLE *)msg)->Length = RUCI_PARA_LEN_SET_RFE_RX_DISABLE;                      \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RFE_MODE) */
#define SET_RUCI_PARA_COMMON_RFE_MODE(msg, mode)                                                                    \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RFE_MODE *)msg)->RuciHeader.u8 = RUCI_PCI_COMMON_CMD_HEADER;                           \
            ((sRUCI_PARA_SET_RFE_MODE *)msg)->Subheader = RUCI_CODE_SET_RFE_MODE;                                   \
            ((sRUCI_PARA_SET_RFE_MODE *)msg)->Length = RUCI_PARA_LEN_SET_RFE_MODE;                                  \
            ((sRUCI_PARA_SET_RFE_MODE *)msg)->Mode = mode;                                                          \
        }while(0)

/*****************************************************************************
* PCI FSK CMD
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_INITIATE_FSK) */
#define SET_RUCI_PARA_FSK_INIT(msg, band_type)                                                                      \
        do{                                                                                                         \
            ((sRUCI_PARA_INITIATE_FSK *)msg)->RuciHeader.u8 = RUCI_PCI_FSK_CMD_HEADER;                              \
            ((sRUCI_PARA_INITIATE_FSK *)msg)->Subheader = RUCI_CODE_INITIATE_FSK;                                   \
            ((sRUCI_PARA_INITIATE_FSK *)msg)->Length = RUCI_PARA_LEN_INITIATE_FSK;                                  \
            ((sRUCI_PARA_INITIATE_FSK *)msg)->BandType = band_type;                                                 \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_FSK_MODEM) */
#define SET_RUCI_PARA_FSK_MODEMT(msg, data_rate, modulation_idx)                                                    \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_FSK_MODEM *)msg)->RuciHeader.u8 = RUCI_PCI_FSK_CMD_HEADER;                             \
            ((sRUCI_PARA_SET_FSK_MODEM *)msg)->Subheader = RUCI_CODE_SET_FSK_MODEM;                                 \
            ((sRUCI_PARA_SET_FSK_MODEM *)msg)->Length = RUCI_PARA_LEN_SET_FSK_MODEM;                                \
            ((sRUCI_PARA_SET_FSK_MODEM *)msg)->DataRate = data_rate;                                                \
            ((sRUCI_PARA_SET_FSK_MODEM *)msg)->ModIndex = modulation_idx;                                           \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_FSK_MAC) */
#define SET_RUCI_PARA_FSK_MAC(msg, crc_type, whitening_en)                                                          \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_FSK_MAC *)msg)->RuciHeader.u8 = RUCI_PCI_FSK_CMD_HEADER;                               \
            ((sRUCI_PARA_SET_FSK_MAC *)msg)->Subheader = RUCI_CODE_SET_FSK_MAC;                                     \
            ((sRUCI_PARA_SET_FSK_MAC *)msg)->Length = RUCI_PARA_LEN_SET_FSK_MAC;                                    \
            ((sRUCI_PARA_SET_FSK_MAC *)msg)->CrcType = crc_type;                                                    \
            ((sRUCI_PARA_SET_FSK_MAC *)msg)->WhiteningEn = whitening_en;                                            \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_FSK_PREAMBLE) */
#define SET_RUCI_PARA_FSK_PREAMBLE(msg, preamble_length)                                                            \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_FSK_PREAMBLE *)msg)->RuciHeader.u8 = RUCI_PCI_FSK_CMD_HEADER;                          \
            ((sRUCI_PARA_SET_FSK_PREAMBLE *)msg)->Subheader = RUCI_CODE_SET_FSK_PREAMBLE;                           \
            ((sRUCI_PARA_SET_FSK_PREAMBLE *)msg)->Length = RUCI_PARA_LEN_SET_FSK_PREAMBLE;                          \
            ((sRUCI_PARA_SET_FSK_PREAMBLE *)msg)->PreambleLength = preamble_length;                                 \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_FSK_SFD) */
#define SET_RUCI_PARA_FSK_SFD(msg, sfd_value)                                                                       \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_FSK_SFD *)msg)->RuciHeader.u8 = RUCI_PCI_FSK_CMD_HEADER;                               \
            ((sRUCI_PARA_SET_FSK_SFD *)msg)->Subheader = RUCI_CODE_SET_FSK_SFD;                                     \
            ((sRUCI_PARA_SET_FSK_SFD *)msg)->Length = RUCI_PARA_LEN_SET_FSK_SFD;                                    \
            ((sRUCI_PARA_SET_FSK_SFD *)msg)->SfdContent = sfd_value;                                                \
        }while(0)


/*****************************************************************************
* PCI BLE CMD
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_INITIATE_BLE) */
#define SET_RUCI_PARA_BLE_INIT(msg)                                                                                 \
        do{                                                                                                         \
            ((sRUCI_PARA_INITIATE_BLE *)msg)->RuciHeader.u8 = RUCI_PCI_BLE_CMD_HEADER;                              \
            ((sRUCI_PARA_INITIATE_BLE *)msg)->Subheader = RUCI_CODE_INITIATE_BLE;                                   \
            ((sRUCI_PARA_INITIATE_BLE *)msg)->Length = RUCI_PARA_LEN_INITIATE_BLE;                                  \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_BLE_MODEM) */
#define SET_RUCI_PARA_BLE_SET_MODEM(msg, data_rate, coded_scheme)                                                   \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_BLE_MODEM *)msg)->RuciHeader.u8 = RUCI_PCI_BLE_CMD_HEADER;                             \
            ((sRUCI_PARA_SET_BLE_MODEM *)msg)->Subheader = RUCI_CODE_SET_BLE_MODEM;                                 \
            ((sRUCI_PARA_SET_BLE_MODEM *)msg)->Length = RUCI_PARA_LEN_SET_BLE_MODEM;                                \
            ((sRUCI_PARA_SET_BLE_MODEM *)msg)->DataRate = data_rate;                                                \
            ((sRUCI_PARA_SET_BLE_MODEM *)msg)->CodedScheme = coded_scheme;                                          \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_BLE_MAC) */
#define SET_RUCI_PARA_BLE_SET_MAC(msg, sfd_value, whitening_en, whitening_value, crc_value)                         \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_BLE_MAC *)msg)->RuciHeader.u8 = RUCI_PCI_BLE_CMD_HEADER;                               \
            ((sRUCI_PARA_SET_BLE_MAC *)msg)->Subheader = RUCI_CODE_SET_BLE_MAC;                                     \
            ((sRUCI_PARA_SET_BLE_MAC *)msg)->Length = RUCI_PARA_LEN_SET_BLE_MAC;                                    \
            ((sRUCI_PARA_SET_BLE_MAC *)msg)->SfdContent = sfd_value;                                                \
            ((sRUCI_PARA_SET_BLE_MAC *)msg)->WhiteningEn = whitening_en;                                            \
            ((sRUCI_PARA_SET_BLE_MAC *)msg)->WhiteningInitValue = whitening_value;                                  \
            ((sRUCI_PARA_SET_BLE_MAC *)msg)->CrcInitValue = crc_value;                                              \
        }while(0)


/*****************************************************************************
* PCI 15P4 CMD
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_INITIATE_ZIGBEE) */
#define SET_RUCI_PARA_ZIGBEE_INIT(msg)                                                                              \
        do{                                                                                                         \
            ((sRUCI_PARA_INITIATE_ZIGBEE *)msg)->RuciHeader.u8 = RUCI_PCI15P4_MAC_CMD_HEADER;                       \
            ((sRUCI_PARA_INITIATE_ZIGBEE *)msg)->Subheader = RUCI_CODE_INITIATE_ZIGBEE;                             \
            ((sRUCI_PARA_INITIATE_ZIGBEE *)msg)->Length = RUCI_PARA_LEN_INITIATE_ZIGBEE;                            \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET15P4_ADDRESS_FILTER) */
#define SET_RUCI_PARA_SET15P4_ADDR_FILTER(msg, mac_promiscuous_mode, short_addr, long_addr_0, long_addr_1, pan_id, is_coordinator)       \
        do{                                                                                                        \
            ((sRUCI_PARA_SET15P4_ADDRESS_FILTER *)msg)->RuciHeader.u8 = RUCI_PCI15P4_MAC_CMD_HEADER;               \
            ((sRUCI_PARA_SET15P4_ADDRESS_FILTER *)msg)->Subheader = RUCI_CODE_SET15P4_ADDRESS_FILTER;              \
            ((sRUCI_PARA_SET15P4_ADDRESS_FILTER *)msg)->Length = RUCI_PARA_LEN_SET15P4_ADDRESS_FILTER;             \
            ((sRUCI_PARA_SET15P4_ADDRESS_FILTER *)msg)->MacPromiscuousMode = mac_promiscuous_mode;                 \
            ((sRUCI_PARA_SET15P4_ADDRESS_FILTER *)msg)->ShortSourceAddress = short_addr;                           \
            ((sRUCI_PARA_SET15P4_ADDRESS_FILTER *)msg)->LongSourceAddress[0] = long_addr_0;                        \
            ((sRUCI_PARA_SET15P4_ADDRESS_FILTER *)msg)->LongSourceAddress[1] = long_addr_1;                        \
            ((sRUCI_PARA_SET15P4_ADDRESS_FILTER *)msg)->PanId = pan_id;                                            \
            ((sRUCI_PARA_SET15P4_ADDRESS_FILTER *)msg)->IsCoordinator = is_coordinator;                            \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET15P4_MAC_PIB) */
#define SET_RUCI_PARA_SET15P4_MAC_PIB(msg, a_unit_backoff_period, mac_ack_wait_duration, mac_max_BE,               \
        mac_max_CSMA_backoffs, mac_max_frame_total_wait_time, mac_max_frame_retries, mac_min_BE)                   \
        do{                                                                                                        \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->RuciHeader.u8 = RUCI_PCI15P4_MAC_CMD_HEADER;                      \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->Subheader = RUCI_CODE_SET15P4_MAC_PIB;                            \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->Length = RUCI_PARA_LEN_SET15P4_MAC_PIB;                           \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->AUnitBackoffPeriod = a_unit_backoff_period;                       \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->MacAckWaitDuration = mac_ack_wait_duration;                       \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->MacMaxBE = mac_max_BE;                                            \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->MacMaxCSMABackoffs = mac_max_CSMA_backoffs;                       \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->MacMaxFrameTotalWaitTime = mac_max_frame_total_wait_time;         \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->MacMaxFrameRetries = mac_max_frame_retries;                       \
            ((sRUCI_PARA_SET15P4_MAC_PIB *)msg)->MacMinBE = mac_min_BE;                                            \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET15P4_AUTO_ACK) */
#define SET_RUCI_PARA_SET15P4_AUTO_ACK(msg, auto_ack_enable_flag)                                                  \
        do{                                                                                                        \
            ((sRUCI_PARA_SET15P4_AUTO_ACK *)msg)->RuciHeader.u8 = RUCI_PCI15P4_MAC_CMD_HEADER;                     \
            ((sRUCI_PARA_SET15P4_AUTO_ACK *)msg)->Subheader = RUCI_CODE_SET15P4_AUTO_ACK;                          \
            ((sRUCI_PARA_SET15P4_AUTO_ACK *)msg)->Length = RUCI_PARA_LEN_SET15P4_AUTO_ACK;                         \
            ((sRUCI_PARA_SET15P4_AUTO_ACK *)msg)->AutoAckEnableFlag = auto_ack_enable_flag;                        \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET15P4_PHY_PIB) */
#define SET_RUCI_PARA_SET15P4_PHY_PIB(msg, a_turnaround_time, phy_cca_mode, phy_cca_threshold, phy_cca_duration)   \
        do{                                                                                                        \
            ((sRUCI_PARA_SET15P4_PHY_PIB *)msg)->RuciHeader.u8 = RUCI_PCI15P4_MAC_CMD_HEADER;                      \
            ((sRUCI_PARA_SET15P4_PHY_PIB *)msg)->Subheader = RUCI_CODE_SET15P4_PHY_PIB;                            \
            ((sRUCI_PARA_SET15P4_PHY_PIB *)msg)->Length = RUCI_PARA_LEN_SET15P4_PHY_PIB;                           \
            ((sRUCI_PARA_SET15P4_PHY_PIB *)msg)->ATurnaroundTime = a_turnaround_time;                              \
            ((sRUCI_PARA_SET15P4_PHY_PIB *)msg)->PhyCcaMode = phy_cca_mode;                                        \
            ((sRUCI_PARA_SET15P4_PHY_PIB *)msg)->PhyCcaThreshold = phy_cca_threshold;                              \
            ((sRUCI_PARA_SET15P4_PHY_PIB *)msg)->PhyCcaDuration = phy_cca_duration;                                \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET15P4_PENDING_BIT) */
#define SET_RUCI_PARA_SET15P4_PENDING_BIT(msg, frame_pending_bit)                                                  \
        do{                                                                                                        \
            ((sRUCI_PARA_SET15P4_PENDING_BIT *)msg)->RuciHeader.u8 = RUCI_PCI15P4_MAC_CMD_HEADER;                  \
            ((sRUCI_PARA_SET15P4_PENDING_BIT *)msg)->Subheader = RUCI_CODE_SET15P4_PENDING_BIT;                    \
            ((sRUCI_PARA_SET15P4_PENDING_BIT *)msg)->Length = RUCI_PARA_LEN_SET15P4_PENDING_BIT;                   \
            ((sRUCI_PARA_SET15P4_PENDING_BIT *)msg)->FramePendingBit = frame_pending_bit;                          \
        }while(0)

/*****************************************************************************
* PCI OQPSK CMD
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_INITIATE_OQPSK) */
#define SET_RUCI_PARA_OQPSK_INIT(msg)                                                                               \
        do{                                                                                                         \
            ((sRUCI_PARA_INITIATE_OQPSK *)msg)->RuciHeader.u8 = RUCI_PCI_OQPSK_CMD_HEADER;                          \
            ((sRUCI_PARA_INITIATE_OQPSK *)msg)->Subheader = RUCI_CODE_INITIATE_OQPSK;                               \
            ((sRUCI_PARA_INITIATE_OQPSK *)msg)->Length = RUCI_PARA_LEN_INITIATE_OQPSK;                              \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_OQPSK_MODEM) */
#define SET_RUCI_PARA_OQPSK_MODEM(msg, data_rate)                                                                   \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_OQPSK_MODEM *)msg)->RuciHeader.u8 = RUCI_PCI_OQPSK_CMD_HEADER;                         \
            ((sRUCI_PARA_SET_OQPSK_MODEM *)msg)->Subheader = RUCI_CODE_SET_OQPSK_MODEM;                             \
            ((sRUCI_PARA_SET_OQPSK_MODEM *)msg)->Length = RUCI_PARA_LEN_SET_OQPSK_MODEM;                            \
            ((sRUCI_PARA_SET_OQPSK_MODEM *)msg)->DataRate = data_rate;                                              \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_OQPSK_MAC) */
#define SET_RUCI_PARA_OQPSK_MAC(msg, crc_type, whitening_en)                                                        \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_OQPSK_MAC *)msg)->RuciHeader.u8 = RUCI_PCI_OQPSK_CMD_HEADER;                           \
            ((sRUCI_PARA_SET_OQPSK_MAC *)msg)->Subheader = RUCI_CODE_SET_OQPSK_MAC;                                 \
            ((sRUCI_PARA_SET_OQPSK_MAC *)msg)->Length = RUCI_PARA_LEN_SET_OQPSK_MAC;                                \
            ((sRUCI_PARA_SET_OQPSK_MAC *)msg)->CrcType = crc_type;                                                  \
            ((sRUCI_PARA_SET_OQPSK_MAC *)msg)->WhiteningEn = whitening_en;                                          \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_OQPSK_EXTRA_PREAMBLE) */
#define SET_RUCI_PARA_OQPSK_EX_PREAMBLE(msg, ex_preamble_length)                                                    \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_OQPSK_EXTRA_PREAMBLE *)msg)->RuciHeader.u8 = RUCI_PCI_OQPSK_CMD_HEADER;                \
            ((sRUCI_PARA_SET_OQPSK_EXTRA_PREAMBLE *)msg)->Subheader = RUCI_CODE_SET_OQPSK_EXTRA_PREAMBLE;           \
            ((sRUCI_PARA_SET_OQPSK_EXTRA_PREAMBLE *)msg)->Length = RUCI_PARA_LEN_SET_OQPSK_EXTRA_PREAMBLE;          \
            ((sRUCI_PARA_SET_OQPSK_EXTRA_PREAMBLE *)msg)->ExtraPrambleLength = ex_preamble_length;                  \
        }while(0)


/*****************************************************************************
* PCI SLINK CMD
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_INITIATE_SLINK) */
#define SET_RUCI_PARA_SLINK_INIT(msg)                                                                               \
        do{                                                                                                         \
            ((sRUCI_PARA_INITIATE_SLINK *)msg)->RuciHeader.u8 = RUCI_PCI_SLINK_CMD_HEADER;                          \
            ((sRUCI_PARA_INITIATE_SLINK *)msg)->Subheader = RUCI_CODE_INITIATE_SLINK;                               \
            ((sRUCI_PARA_INITIATE_SLINK *)msg)->CmdLen = RUCI_PARA_LEN_INITIATE_SLINK;                              \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_SLINK_MODEM) */
#define SET_RUCI_PARA_SLINK_MODEM(msg, band_width, auto_config_mode)                                                \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_SLINK_MODEM *)msg)->RuciHeader.u8 = RUCI_PCI_SLINK_CMD_HEADER;                         \
            ((sRUCI_PARA_SET_SLINK_MODEM *)msg)->Subheader = RUCI_CODE_SET_SLINK_MODEM;                             \
            ((sRUCI_PARA_SET_SLINK_MODEM *)msg)->CmdLen = RUCI_PARA_LEN_SET_SLINK_MODEM;                            \
            ((sRUCI_PARA_SET_SLINK_MODEM *)msg)->Bandwidth = band_width;                                            \
            ((sRUCI_PARA_SET_SLINK_MODEM *)msg)->AutoConfigMode = auto_config_mode;                                 \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_SLINK_CAD) */
#define SET_RUCI_PARA_SLINK_CAD(msg, status_cnt_num, status_threshild, preamble_cnt_num, cad_time)                  \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_SLINK_CAD *)msg)->RuciHeader.u8 = RUCI_PCI_SLINK_CMD_HEADER;                           \
            ((sRUCI_PARA_SET_SLINK_CAD *)msg)->Subheader = RUCI_CODE_SET_SLINK_CAD;                                 \
            ((sRUCI_PARA_SET_SLINK_CAD *)msg)->CmdLen = RUCI_PARA_LEN_SET_SLINK_CAD;                                \
            ((sRUCI_PARA_SET_SLINK_CAD *)msg)->StatusCountNumber = status_cnt_num;                                  \
            ((sRUCI_PARA_SET_SLINK_CAD *)msg)->StatusThreshold = status_threshild;                                  \
            ((sRUCI_PARA_SET_SLINK_CAD *)msg)->PreambleCountNumber = preamble_cnt_num;                              \
            ((sRUCI_PARA_SET_SLINK_CAD *)msg)->CadOnTime = cad_time;                                                \
        }while(0)


/*****************************************************************************
* PCI DATA
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_TX_CONTROL_FIELD) */
#define SET_RUCI_PARA_TX_CONTROL_FIELD(msg, length, mac_control, dsn)                                                \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_TX_CONTROL_FIELD *)msg)->RuciHeader.u8 = RUCI_PCI_DATA_HEADER;                         \
            ((sRUCI_PARA_SET_TX_CONTROL_FIELD *)msg)->Subheader = RUCI_CODE_SET_TX_CONTROL_FIELD;                   \
            ((sRUCI_PARA_SET_TX_CONTROL_FIELD *)msg)->Length = length + RUCI_PARA_LEN_SET_TX_CONTROL_FIELD;         \
            ((sRUCI_PARA_SET_TX_CONTROL_FIELD *)msg)->MacControl = mac_control;                          \
            ((sRUCI_PARA_SET_TX_CONTROL_FIELD *)msg)->MacDsn = dsn;                                                    \
        }while(0)


/*****************************************************************************
* PCI APCI RF
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RF_CHANNEL) */
#define SET_RUCI_PARA_APCI_RF_CHANNEL(msg, rf_channel)                                                              \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RF_CHANNEL *)msg)->RuciHeader.u8 = RUCI_APCI_RF_CMD_HEADER;                            \
            ((sRUCI_PARA_SET_RF_CHANNEL *)msg)->Subheader = RUCI_CODE_SET_RF_CHANNEL;                               \
            ((sRUCI_PARA_SET_RF_CHANNEL *)msg)->Length = RUCI_PARA_LEN_SET_RF_CHANNEL;                              \
            ((sRUCI_PARA_SET_RF_CHANNEL *)msg)->RfChannel = rf_channel;                                             \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RF_TX_POWER) */
#define SET_RUCI_PARA_APCI_TX_POWER(msg, tx_power)                                                                  \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RF_TX_POWER *)msg)->RuciHeader.u8 = RUCI_APCI_RF_CMD_HEADER;                           \
            ((sRUCI_PARA_SET_RF_TX_POWER *)msg)->Subheader = RUCI_CODE_SET_RF_TX_POWER;                             \
            ((sRUCI_PARA_SET_RF_TX_POWER *)msg)->Length = RUCI_PARA_LEN_SET_RF_TX_POWER;                            \
            ((sRUCI_PARA_SET_RF_TX_POWER *)msg)->TxPower = tx_power;                                                \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RF_CONTINUOUS_WAVE) */
#define SET_RUCI_PARA_APCI_RF_CTN_WAVE(msg, is_enable)                                                              \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RF_CONTINUOUS_WAVE *)msg)->RuciHeader.u8 = RUCI_APCI_RF_CMD_HEADER;                    \
            ((sRUCI_PARA_SET_RF_CONTINUOUS_WAVE *)msg)->Subheader = RUCI_CODE_SET_RF_CONTINUOUS_WAVE;               \
            ((sRUCI_PARA_SET_RF_CONTINUOUS_WAVE *)msg)->Length = RUCI_PARA_LEN_SET_RF_CONTINUOUS_WAVE;              \
            ((sRUCI_PARA_SET_RF_CONTINUOUS_WAVE *)msg)->EnableFlag = is_enable;                                     \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RF_SLEEP_ON_OFF) */
#define SET_RUCI_PARA_APCI_RF_SLEEP(msg, is_enable)                                                                 \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RF_SLEEP_ON_OFF *)msg)->RuciHeader.u8 = RUCI_APCI_RF_CMD_HEADER;                       \
            ((sRUCI_PARA_SET_RF_SLEEP_ON_OFF *)msg)->Subheader = RUCI_CODE_SET_RF_SLEEP_ON_OFF;                     \
            ((sRUCI_PARA_SET_RF_SLEEP_ON_OFF *)msg)->Length = RUCI_PARA_LEN_SET_RF_SLEEP_ON_OFF;                    \
            ((sRUCI_PARA_SET_RF_SLEEP_ON_OFF *)msg)->EnableFlag = is_enable;                                        \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_DETECT_ENERGY) */
#define SET_RUCI_PARA_APCI_DETECT_ENERGY(msg, energy)                                                               \
        do{                                                                                                         \
            ((sRUCI_PARA_DETECT_ENERGY *)msg)->RuciHeader.u8 = RUCI_APCI_RF_CMD_HEADER;                             \
            ((sRUCI_PARA_DETECT_ENERGY *)msg)->Subheader = RUCI_CODE_DETECT_ENERGY;                                 \
            ((sRUCI_PARA_DETECT_ENERGY *)msg)->Length = RUCI_PARA_LEN_DETECT_ENERGY;                                \
            ((sRUCI_PARA_DETECT_ENERGY *)msg)->RfChannel = energy;                                                  \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_MODEM) */
#define SET_RUCI_PARA_APCI_MODEM(msg, modem_type, clock_mode, data_rate)                                            \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_MODEM *)msg)->RuciHeader.u8 = RUCI_APCI_RF_CMD_HEADER;                                 \
            ((sRUCI_PARA_SET_MODEM *)msg)->Subheader = RUCI_CODE_SET_MODEM;                                         \
            ((sRUCI_PARA_SET_MODEM *)msg)->Length = RUCI_PARA_LEN_SET_MODEM;                                        \
            ((sRUCI_PARA_SET_MODEM *)msg)->ModemType = modem_type;                                                  \
            ((sRUCI_PARA_SET_MODEM *)msg)->ClockMode = clock_mode;                                                  \
            ((sRUCI_PARA_SET_MODEM *)msg)->DataRate = data_rate;                                                    \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_ACCESS_ADDRESS) */
#define SET_RUCI_PARA_APCI_ACCESS_ADDR(msg, access_addr)                                                            \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_ACCESS_ADDRESS *)msg)->RuciHeader.u8 = RUCI_APCI_RF_CMD_HEADER;                        \
            ((sRUCI_PARA_SET_ACCESS_ADDRESS *)msg)->Subheader = RUCI_CODE_SET_ACCESS_ADDRESS;                       \
            ((sRUCI_PARA_SET_ACCESS_ADDRESS *)msg)->Length = RUCI_PARA_LEN_SET_ACCESS_ADDRESS;                      \
            ((sRUCI_PARA_SET_ACCESS_ADDRESS *)msg)->AccessAddress = access_addr;                                    \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_ACCESS_ADDRESS_FILTER) */
#define SET_RUCI_PARA_APCI_ACCESS_ADDR_FILTER(msg, is_enable)                                                       \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_ACCESS_ADDRESS_FILTER *)msg)->RuciHeader.u8 = RUCI_APCI_RF_CMD_HEADER;                 \
            ((sRUCI_PARA_SET_ACCESS_ADDRESS_FILTER *)msg)->Subheader = RUCI_CODE_SET_ACCESS_ADDRESS_FILTER;         \
            ((sRUCI_PARA_SET_ACCESS_ADDRESS_FILTER *)msg)->Length = RUCI_PARA_LEN_SET_ACCESS_ADDRESS_FILTER;        \
            ((sRUCI_PARA_SET_ACCESS_ADDRESS_FILTER *)msg)->AccessAddressFilterEnable = is_enable;                   \
        }while(0)


/*****************************************************************************
* PCI APCI RX
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_TX_ON) */
#define SET_RUCI_PARA_APCI_TX_ON(msg)                                                                               \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_TX_ON *)msg)->RuciHeader.u8 = RUCI_APCI_TX_CMD_HEADER;                                 \
            ((sRUCI_PARA_SET_TX_ON *)msg)->Subheader = RUCI_CODE_SET_TX_ON;                                         \
            ((sRUCI_PARA_SET_TX_ON *)msg)->Length = RUCI_PARA_LEN_SET_TX_ON;                                        \
        }while(0)


/*****************************************************************************
* PCI APCI RX
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RX_ON) */
#define SET_RUCI_PARA_APCI_RX_ON(msg)                                                                               \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RX_ON *)msg)->RuciHeader.u8 = RUCI_APCI_RX_CMD_HEADER;                                 \
            ((sRUCI_PARA_SET_RX_ON *)msg)->Subheader = RUCI_CODE_SET_RX_ON;                                         \
            ((sRUCI_PARA_SET_RX_ON *)msg)->Length = RUCI_PARA_LEN_SET_RX_ON;                                        \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_RX_OFF) */
#define SET_RUCI_PARA_APCI_RX_OFF(msg)                                                                              \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_RX_OFF *)msg)->RuciHeader.u8 = RUCI_APCI_RX_CMD_HEADER;                                \
            ((sRUCI_PARA_SET_RX_OFF *)msg)->Subheader = RUCI_CODE_SET_RX_OFF;                                       \
            ((sRUCI_PARA_SET_RX_OFF *)msg)->Length = RUCI_PARA_LEN_SET_RX_OFF;                                      \
        }while(0)


/*****************************************************************************
* PCI HOST CND
******************************************************************************/
/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SFR_READ) */
#define SET_RUCI_PARA_HOST_SFR_READ(msg, addr)                                                                      \
        do{                                                                                                         \
            ((sRUCI_PARA_SFR_READ *)msg)->RuciHeader.u8 = RUCI_HOST_CMD_HEADER;                                     \
            ((sRUCI_PARA_SFR_READ *)msg)->Subheader = RUCI_CODE_SFR_READ;                                           \
            ((sRUCI_PARA_SFR_READ *)msg)->Length = RUCI_PARA_LEN_SFR_READ;                                          \
            ((sRUCI_PARA_SFR_READ *)msg)->Addr = addr;                                                              \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SFR_WRITE) */
#define SET_RUCI_PARA_HOST_SFR_WRITE(msg, addr, data)                                                               \
        do{                                                                                                         \
            ((sRUCI_PARA_SFR_WRITE *)msg)->RuciHeader.u8 = RUCI_HOST_CMD_HEADER;                                    \
            ((sRUCI_PARA_SFR_WRITE *)msg)->Subheader = RUCI_CODE_SFR_WRITE;                                         \
            ((sRUCI_PARA_SFR_WRITE *)msg)->Length = RUCI_PARA_LEN_SFR_WRITE;                                        \
            ((sRUCI_PARA_SFR_WRITE *)msg)->Addr = addr;                                                             \
            ((sRUCI_PARA_SFR_WRITE *)msg)->Data = data;                                                             \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_IO_READ) */
#define SET_RUCI_PARA_HOST_IO_READ(msg, q_index, data_length)                                                       \
        do{                                                                                                         \
            ((sRUCI_PARA_IO_READ *)msg)->RuciHeader.u8 = RUCI_HOST_CMD_HEADER;                                      \
            ((sRUCI_PARA_IO_READ *)msg)->Subheader = RUCI_CODE_IO_READ;                                             \
            ((sRUCI_PARA_IO_READ *)msg)->Length = RUCI_PARA_LEN_IO_READ;                                            \
            ((sRUCI_PARA_IO_READ *)msg)->Qidx = q_index;                                                            \
            ((sRUCI_PARA_IO_READ *)msg)->DataLength = data_length;                                                  \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_IO_WRITE) */
#define SET_RUCI_PARA_HOST_IO_WRITE(msg, q_index, data_length)                                                      \
        do{                                                                                                         \
            ((sRUCI_PARA_IO_WRITE *)msg)->RuciHeader.u8 = RUCI_HOST_CMD_HEADER;                                     \
            ((sRUCI_PARA_IO_WRITE *)msg)->Subheader = RUCI_CODE_IO_WRITE;                                           \
            ((sRUCI_PARA_IO_WRITE *)msg)->Length = data_length + (RUCI_LEN_IO_WRITE - RUCI_PARA_LEN_IO_WRITE);      \
            ((sRUCI_PARA_IO_WRITE *)msg)->Qidx = q_index;                                                           \
            ((sRUCI_PARA_IO_WRITE *)msg)->DataLength = data_length;                                                 \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_MEM_READ) */
#define SET_RUCI_PARA_HOST_MEM_READ(msg, addr, data_length)                                                         \
        do{                                                                                                         \
            ((sRUCI_PARA_MEM_READ *)msg)->RuciHeader.u8 = RUCI_HOST_CMD_HEADER;                                     \
            ((sRUCI_PARA_MEM_READ *)msg)->Subheader = RUCI_CODE_MEM_READ;                                           \
            ((sRUCI_PARA_MEM_READ *)msg)->Length = RUCI_PARA_LEN_MEM_READ;                                          \
            ((sRUCI_PARA_MEM_READ *)msg)->Addr = addr;                                                              \
            ((sRUCI_PARA_MEM_READ *)msg)->DataLength = data_length;                                                 \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_MEM_WRITE) */
#define SET_RUCI_PARA_HOST_MEM_WRITE(msg, addr, data_kength)                                                        \
        do{                                                                                                         \
            ((sRUCI_PARA_MEM_WRITE *)msg)->RuciHeader.u8 = RUCI_HOST_CMD_HEADER;                                    \
            ((sRUCI_PARA_MEM_WRITE *)msg)->Subheader = RUCI_CODE_MEM_WRITE;                                         \
            ((sRUCI_PARA_MEM_WRITE *)msg)->Length = data_kength + (RUCI_LEN_MEM_WRITE - RUCI_PARA_LEN_MEM_WRITE);   \
            ((sRUCI_PARA_MEM_WRITE *)msg)->Addr = addr;                                                             \
            ((sRUCI_PARA_MEM_WRITE *)msg)->DataLength = data_kength;                                                \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_REG_READ) */
#define SET_RUCI_PARA_HOST_REG_READ(msg, addr)                                                                      \
        do{                                                                                                         \
            ((sRUCI_PARA_REG_READ *)msg)->RuciHeader.u8 = RUCI_HOST_CMD_HEADER;                                     \
            ((sRUCI_PARA_REG_READ *)msg)->Subheader = RUCI_CODE_REG_READ;                                           \
            ((sRUCI_PARA_REG_READ *)msg)->Length = RUCI_PARA_LEN_REG_READ;                                          \
            ((sRUCI_PARA_REG_READ *)msg)->Addr = addr;                                                              \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_REG_WRITE) */
#define SET_RUCI_PARA_HOST_REG_WRITE(msg, addr, data)                                                               \
        do{                                                                                                         \
            ((sRUCI_PARA_REG_WRITE *)msg)->RuciHeader.u8 = RUCI_HOST_CMD_HEADER;                                    \
            ((sRUCI_PARA_REG_WRITE *)msg)->Subheader = RUCI_CODE_REG_WRITE;                                         \
            ((sRUCI_PARA_REG_WRITE *)msg)->Length = RUCI_PARA_LEN_REG_WRITE;                                        \
            ((sRUCI_PARA_REG_WRITE *)msg)->Addr = addr;                                                             \
            ((sRUCI_PARA_REG_WRITE *)msg)->Data = data;                                                             \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_PMU_CFG_BY_RF) */
#define SET_RUCI_PARA_HOST_PMU_CFG(msg, rf_band)                                                                    \
        do{                                                                                                         \
            ((sRUCI_PARA_PMU_CFG_BY_RF *)msg)->RuciHeader.u8 = RUCI_HOST_CMD_HEADER;                                \
            ((sRUCI_PARA_PMU_CFG_BY_RF *)msg)->Subheader = RUCI_CODE_PMU_CFG_BY_RF;                                 \
            ((sRUCI_PARA_PMU_CFG_BY_RF *)msg)->Length = RUCI_PARA_LEN_PMU_CFG_BY_RF;                                \
            ((sRUCI_PARA_PMU_CFG_BY_RF *)msg)->RfBand = rf_band;                                                    \
        }while(0)



/*****************************************************************************
* COMMON SYS CMD
******************************************************************************/

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_GET_FW_VER) */
#define SET_RUCI_PARA_COMMON_GET_FW_VER(msg)                                                                        \
        do{                                                                                                         \
            ((sRUCI_PARA_GET_FW_VER *)msg)->RuciHeader.u8 = RUCI_CMN_SYS_CMD_HEADER;                                \
            ((sRUCI_PARA_GET_FW_VER *)msg)->Subheader = RUCI_CODE_GET_FW_VER;                                       \
            ((sRUCI_PARA_GET_FW_VER *)msg)->Length = RUCI_PARA_LEN_GET_FW_VER;                                      \
        }while(0)



/*****************************************************************************
* COMMON HAL CMD
******************************************************************************/

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_AGC) */
#define SET_RUCI_PARA_COMMON_AGC(msg, agc_enable, lna_gain, vga_gain, tia_gain)                                     \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_AGC *)msg)->RuciHeader.u8 = RUCI_CMN_HAL_CMD_HEADER;                                   \
            ((sRUCI_PARA_SET_AGC *)msg)->Subheader = RUCI_CODE_SET_AGC;                                             \
            ((sRUCI_PARA_SET_AGC *)msg)->Length = RUCI_PARA_LEN_SET_AGC;                                            \
            ((sRUCI_PARA_SET_AGC *)msg)->AgcEnable = agc_enable;                                                    \
            ((sRUCI_PARA_SET_AGC *)msg)->LnaGain = lna_gain;                                                        \
            ((sRUCI_PARA_SET_AGC *)msg)->VgaGain = vga_gain;                                                        \
            ((sRUCI_PARA_SET_AGC *)msg)->TiaGain = tia_gain;                                                        \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_CALIBRATION_ENABLE) */
#define SET_RUCI_PARA_COMMON_CALIBRATION_EN(msg, rf_band)                                                           \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_CALIBRATION_ENABLE *)msg)->RuciHeader.u8 = RUCI_CMN_HAL_CMD_HEADER;                    \
            ((sRUCI_PARA_SET_CALIBRATION_ENABLE *)msg)->Subheader = RUCI_CODE_SET_CALIBRATION_ENABLE;               \
            ((sRUCI_PARA_SET_CALIBRATION_ENABLE *)msg)->Length = RUCI_PARA_LEN_SET_CALIBRATION_ENABLE;              \
            ((sRUCI_PARA_SET_CALIBRATION_ENABLE *)msg)->RfBand = rf_band;                                           \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_CALIBRATION_SETTING) */
#define SET_RUCI_PARA_COMMON_CALIBRATION_SETTING(msg, rf_band, status, rx_filter, tx_lo_0, tx_lo_1,                 \
            tx_sb_0, tx_sb_1, tx_sb_2)                                                                              \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->RuciHeader.u8 = RUCI_CMN_HAL_CMD_HEADER;                   \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->Subheader = RUCI_CODE_SET_CALIBRATION_SETTING;             \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->Length = RUCI_PARA_LEN_SET_CALIBRATION_SETTING;            \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->RfBand = rf_band;                                          \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->Status = status;                                           \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->RxFilter = rx_filter;                                      \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->TxLo[0] = tx_lo_0;                                         \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->TxLo[1] = tx_lo_1;                                         \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->TxSb[0] = tx_sb_0;                                         \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->TxSb[1] = tx_sb_1;                                         \
            ((sRUCI_PARA_SET_CALIBRATION_SETTING *)msg)->TxSb[2] = tx_sb_2;                                         \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_SET_TX_POWER) */
#define SET_RUCI_PARA_COMMON_TX_POWER(msg, rf_band, tx_power)                                                       \
        do{                                                                                                         \
            ((sRUCI_PARA_SET_TX_POWER *)msg)->RuciHeader.u8 = RUCI_CMN_HAL_CMD_HEADER;                              \
            ((sRUCI_PARA_SET_TX_POWER *)msg)->Subheader = RUCI_CODE_SET_TX_POWER;                                   \
            ((sRUCI_PARA_SET_TX_POWER *)msg)->Length = RUCI_PARA_LEN_SET_TX_POWER;                                  \
            ((sRUCI_PARA_SET_TX_POWER *)msg)->RfBand = rf_band;                                                     \
            ((sRUCI_PARA_SET_TX_POWER *)msg)->TxPower = tx_power;                                                   \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_GET_TEMPERATURE_RPT) */
#define SET_RUCI_PARA_COMMON_GET_TEMPERATURE_REPOT(msg)                                                             \
        do{                                                                                                         \
            ((sRUCI_PARA_GET_TEMPERATURE_RPT *)msg)->RuciHeader.u8 = RUCI_CMN_HAL_CMD_HEADER;                       \
            ((sRUCI_PARA_GET_TEMPERATURE_RPT *)msg)->Subheader = RUCI_CODE_GET_TEMPERATURE_RPT;                     \
            ((sRUCI_PARA_GET_TEMPERATURE_RPT *)msg)->Length = RUCI_PARA_LEN_GET_TEMPERATURE_RPT;                    \
        }while(0)

/* User should provide msg buffer is greater than sizeof(sRUCI_PARA_GET_VOLTAGE_RPT) */
#define SET_RUCI_PARA_COMMON_GET_VOLTAGE_REPOT(msg)                                                                 \
        do{                                                                                                         \
            ((sRUCI_PARA_GET_VOLTAGE_RPT *)msg)->RuciHeader.u8 = RUCI_CMN_HAL_CMD_HEADER;                           \
            ((sRUCI_PARA_GET_VOLTAGE_RPT *)msg)->Subheader = RUCI_CODE_GET_VOLTAGE_RPT;                             \
            ((sRUCI_PARA_GET_VOLTAGE_RPT *)msg)->Length = RUCI_PARA_LEN_GET_VOLTAGE_RPT;                            \
        }while(0)

#endif /* _RUCI_H */
