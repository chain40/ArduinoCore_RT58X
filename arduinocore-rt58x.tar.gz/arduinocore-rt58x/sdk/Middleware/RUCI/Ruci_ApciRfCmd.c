/******************************************************************************
*
* @File			Ruci_ApciRfCmd.c
* @Version
* $Revision:4157
* $Date: 2021-12-27
* @Brief
* @Note
* Copyright (C) 2019 Rafael Microelectronics Inc. All rights reserved.
*
*****************************************************************************/

/******************************************************************************
* INCLUDES
******************************************************************************/
#include "Ruci_ApciRfCmd.h"

#if (RUCI_ENDIAN_INVERSE)
#if (RUCI_ENABLE_APCI)

/******************************************************************************
* GLOBAL PARAMETERS
******************************************************************************/
// RUCI: SetRfChannel ----------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfChannel[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfChannel[] = {
    1, 1, 1, 1
};

// RUCI: SetRfContinuousWave ---------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfContinuousWave[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfContinuousWave[] = {
    1, 1, 1, 1
};

// RUCI: SetRfSleepOnOff -------------------------------------------------------
const uint8_t Ruci_ElmtType_SetRfSleepOnOff[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetRfSleepOnOff[] = {
    1, 1, 1, 1
};

// RUCI: DetectEnergy ----------------------------------------------------------
const uint8_t Ruci_ElmtType_DetectEnergy[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_DetectEnergy[] = {
    1, 1, 1, 1
};

// RUCI: SetModem --------------------------------------------------------------
const uint8_t Ruci_ElmtType_SetModem[] = {
    1, 1, 1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetModem[] = {
    1, 1, 1, 1, 1, 1
};

// RUCI: SetAccessAddress ------------------------------------------------------
const uint8_t Ruci_ElmtType_SetAccessAddress[] = {
    1, 1, 1, 4
};
const uint8_t Ruci_ElmtNum_SetAccessAddress[] = {
    1, 1, 1, 1
};

// RUCI: SetAccessAddressFilter ------------------------------------------------
const uint8_t Ruci_ElmtType_SetAccessAddressFilter[] = {
    1, 1, 1, 1
};
const uint8_t Ruci_ElmtNum_SetAccessAddressFilter[] = {
    1, 1, 1, 1
};

#endif /* RUCI_ENABLE_APCI */
#endif /* RUCI_ENDIAN_INVERSE */
