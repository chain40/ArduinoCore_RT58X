/** @file
 *
 * @brief SAR ADC driver file.
 *
 */

#ifndef __SADC_H__
#define __SADC_H__

/**************************************************************************************************
 *    INCLUDES
 *************************************************************************************************/


/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/


/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/
#define SADC_TEST_MODE        0

#if (SADC_TEST_MODE == 1)
#define SADC_TEST_VALUE         0x5AF
#endif

#define SADC_PNSEL_CH_REG_DEFAULT      0x240000FF
#define SADC_SET_CH_REG_DEFAULT        0x80000000
#define SADC_THD_CH_REG_DEFAULT        0x3FFF0000

#define SADC_MONITOR_LOW_THD_DEFAULT   0
#define SADC_MONITOR_HIGH_THD_DEFAULT  0x3FFF


/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/
typedef uint16_t sadc_value_t;

typedef enum
{
    SADC_RES_8BIT  = 0,             /**< 8 bit resolution. */
    SADC_RES_10BIT = 1,             /**< 10 bit resolution. */
    SADC_RES_12BIT = 2,             /**< 12 bit resolution. */
    SADC_RES_14BIT = 3,             /**< 14 bit resolution. */
} sadc_config_resolution_t;

typedef enum
{
    SADC_OVERSAMPLE_0 = 0,          /**< No oversampling*/
    SADC_OVERSAMPLE_2 = 1,          /**< Oversampling ratio multiple 2*/
    SADC_OVERSAMPLE_4 = 2,          /**< Oversampling ratio multiple 4*/
    SADC_OVERSAMPLE_8 = 3,          /**< Oversampling ratio multiple 8*/
    SADC_OVERSAMPLE_16 = 4,         /**< Oversampling ratio multiple 16*/
    SADC_OVERSAMPLE_32 = 5,         /**< Oversampling ratio multiple 32*/
    SADC_OVERSAMPLE_64 = 6,         /**< Oversampling ratio multiple 64*/
    SADC_OVERSAMPLE_128 = 7,        /**< Oversampling ratio multiple 128*/
    SADC_OVERSAMPLE_256 = 8,        /**< Oversampling ratio multiple 256*/
} sadc_config_oversample_t;

typedef enum
{
    SADC_SAMPLE_START = 0,          /**< SADC conversion is started by software SADC start in SADC sample one shot mode*/
    SADC_SAMPLE_TIMER = 1,          /**< SADC conversion is started by Timer in SADC sample timer mode*/
} sadc_config_sample_t;

typedef enum
{
    SADC_TIMER_SYSTEM_CLK = 0,      /**< Select timer clock source to system clock(48MHz/32MHz) in SADC sample timer mode*/
    SADC_TIMER_SLOW_CLK = 1,        /**< Select timer clock source to slow clock (32KHz) in SADC sample timer mode*/
} sadc_config_timer_clk_t;

typedef enum
{
    SADC_CHANNEL_0      = 0,   /**< Channel 0. */
    SADC_CHANNEL_1      = 1,   /**< Channel 1. */
    SADC_CHANNEL_2      = 2,   /**< Channel 2. */
    SADC_CHANNEL_3      = 3,   /**< Channel 3. */
    SADC_CHANNEL_4      = 4,   /**< Channel 4. */
    SADC_CHANNEL_5      = 5,   /**< Channel 5. */
    SADC_CHANNEL_6      = 6,   /**< Channel 6. */
    SADC_CHANNEL_7      = 7,   /**< Channel 7. */
    SADC_CHANNEL_8      = 8,   /**< Channel 8. */
    SADC_CHANNEL_9      = 9,   /**< Channel 9. */
    SADC_CHANNEL_MAX    = 10,   /**< Max Channel 10. */
} sadc_config_channel_t;

/**
 * @enum sadc_config_input_t
 * @brief Input selection of the analog-to-digital converter.
 */
typedef enum
{
    SADC_AIN_0        = 0,   /**< Input 0. */
    SADC_AIN_1        = 1,   /**< Input 1. */
    SADC_AIN_2        = 2,   /**< Input 2. */
    SADC_AIN_3        = 3,   /**< Input 3. */
    SADC_AIN_4        = 4,   /**< Input 4. */
    SADC_AIN_5        = 5,   /**< Input 5. */
    SADC_AIN_6        = 6,   /**< Input 6. */
    SADC_AIN_7        = 7,   /**< Input 7. */
    SADC_AIN_8        = 8,   /**< Input 8. Temperature Sensor */
    SADC_TEMPERATURE  = 8,   /**< Input 8. Temperature Sensor */
    SADC_AIN_9        = 9,   /**< Input 9. Bypass VGA */
    SADC_BYPASS_VGA   = 9,   /**< Input 9. Bypass VGA */
    SADC_AIN_10       = 10,  /**< Input 10. VBAT */
    SADC_VBAT         = 10,  /**< Input 10. VBAT */
    SADC_AIN_DISABLED = 11,  /**< No input selected. */
} sadc_config_input_t;

typedef enum
{
    SADC_TACQ_EDLY_TIME_0P3US      = 0,
    SADC_TACQ_EDLY_TIME_1US        = 1,
    SADC_TACQ_EDLY_TIME_2US        = 2,
    SADC_TACQ_EDLY_TIME_3US        = 3,
    SADC_TACQ_EDLY_TIME_4US        = 4,
    SADC_TACQ_EDLY_TIME_8US        = 5,
    SADC_TACQ_EDLY_TIME_12US       = 6,
    SADC_TACQ_EDLY_TIME_16US       = 7,
} sadc_config_tacq_edly_t;

typedef enum
{
    SADC_BURST_DISABLE    = 0,
    SADC_BURST_ENABLE     = 1,
} sadc_config_burst_t;

/**
 * @brief SADC callback types.
 */
typedef enum
{
    SADC_CB_DONE,    /**< CB generated when the buffer is filled with samples. */
    SADC_CB_SAMPLE,  /**< CB generated when the requested channel is sampled. */
} sadc_cb_type_t;

/**
 * @brief SADC callback types.
 */
typedef enum
{
    SADC_CONVERT_IDLE  = 0,
    SADC_CONVERT_START,
    SADC_CONVERT_DONE,
} sadc_convert_state_t;

typedef struct
{
    uint32_t enable;
    uint32_t start_addr;
    uint16_t seg_size;
    uint16_t blk_size;
} sadc_config_xdma_t;

typedef struct
{
    sadc_config_timer_clk_t timer_clk_src;
    uint32_t timer_clk_div;
} sadc_config_timer_t;

/**
 * @brief ADC configuration.
 */
typedef struct
{
    //uint8_t interrupt_priority;                 /**< Priority of SADC interrupt*/
    sadc_int_t                sadc_int_mask;
    sadc_config_resolution_t  sadc_resolution;    /**< SADC resolution*/
    sadc_config_oversample_t  sadc_oversample;    /**< SADC oversample*/
    sadc_config_xdma_t        sadc_xdma;          /**< SADC XDMA*/
    sadc_config_sample_t      sadc_sample_mode;   /**< SADC sample mode*/
    sadc_config_timer_t       sadc_timer;         /**< SADC timer*/
} sadc_config_t;

typedef struct
{
    sadc_config_channel_t    ch_sel;
    sadc_config_input_t      pi_sel;
    sadc_config_input_t      ni_sel;
    uint32_t                 gain;
    uint32_t                 pull;
    sadc_config_tacq_edly_t  tacq;
    sadc_config_tacq_edly_t  edly;
    sadc_config_burst_t      burst;
    uint32_t                 low_thd;
    uint32_t                 high_thd;
} sadc_channel_config_t;

/**
 * @brief Analog-to-digital converter driver DONE cb.
 */
typedef struct
{
    sadc_value_t *p_buffer;  /**< Pointer to buffer with converted samples. */
    uint16_t      size;      /**< Number of samples in the buffer. */
} sadc_done_cb_t;

/**
 * @brief Analog-to-digital converter driver SAMPLE cb.
 */
typedef struct
{
    sadc_value_t  value;    /**< Converted sample. */
    uint32_t      channel;
} sadc_sample_cb_t;

/**
 * @brief Analog-to-digital converter driver cb.
 */
typedef struct
{
    sadc_cb_type_t type;     /**< CB type. */
    union
    {
        sadc_done_cb_t   done;   /**< Data for DONE cb. */
        sadc_sample_cb_t sample; /**< Data for SAMPLE cb. */
    } data;
} sadc_cb_t;

/**
 * @brief User cb handler prototype.
 *
 * This function is called when the requested number of samples has been processed.
 *
 * @param p_cb CB.
 */
typedef void (*sadc_isr_handler_t)(sadc_cb_t *p_cb);


/**************************************************************************************************
 *    Global Prototypes
 *************************************************************************************************/
#define SADC_RESET()                      (SADC->SADC_CTL1.bit.CFG_SADC_RST = ENABLE)           /**< Reset the SADC module*/
#define SADC_ENABLE()                     (SADC->SADC_CTL0.bit.CFG_SADC_ENA = ENABLE)           /**< Enable the SADC module*/
#define SADC_START()                      (SADC->SADC_CTL2.bit.CFG_SADC_START = ENABLE)         /**< Start the SADC module to trigger SADC conversion*/
#define SADC_RES_BIT(para_set)            (SADC->SADC_SET1.bit.CFG_SADC_BIT = para_set)         /**< Configure the SADC resolution*/
#define SADC_OVERSAMPLE_RATE(para_set)    (SADC->SADC_SET1.bit.CFG_SADC_OSR = para_set)         /**< Configure the SADC oversample time value*/
#define SADC_SAMPLE_MODE(para_set)        (SADC->SADC_SET0.bit.CFG_SADC_SMP_MODE = para_set)    /**< Configure the SADC sample rate mode (one shot mode and timer mode)*/
#define SADC_GET_SAMPLE_MODE()            (SADC->SADC_SET0.bit.CFG_SADC_SMP_MODE)               /**< Return the SADC sample rate mode (one shot mode and timer mode)*/
#define SADC_TIMER_CLOCK(para_set)        (SADC->SADC_SET0.bit.CFG_SADC_TMR_CKSEL = para_set)   /**< Select timer clock source in SADC sample timer mode*/
#define SADC_TIMER_CLOCK_DIV(para_set)    (SADC->SADC_SET0.bit.CFG_SADC_TMR_CKDIV = para_set)   /**< Configure timer clock divisor (1~65535) in SADC sample timer mode*/
#define SADC_GET_ADC_VALUE()              (SADC->SADC_R0.bit.SADC_O)                            /**< Return the last SADC conversion result data for regular channel*/
#define SADC_GET_ADC_CHANNEL()            (SADC->SADC_R0.bit.SADC_O_CHX)                        /**< Return the last SADC conversion channel*/
#define SADC_GET_XDMA_START_ADDRESS()     (SADC->SADC_WDMA_SET1)                                /**< Return the XDMA buffer address*/
#define SADC_GET_XDMA_NEXT_ADDRESS()      (SADC->SADC_WDMA_R0)                                  /**< Return the status of XDMA next pointer address*/
#define SADC_GET_XDMA_RESULT_NUMBER()     (SADC->SADC_R1.bit.SADC_NUM_RES)                      /**< Return the number of SADC result write into WDMA since last SADC start*/
#define SADC_GET_RES_BIT()                (SADC->SADC_SET1.bit.CFG_SADC_BIT)                    /**< Return the SADC resolution*/
#define SADC_SET_XDMA_START()             (SADC->SADC_WDMA_CTL0.bit.CFG_SADC_WDMA_CTL0 = ENABLE)/**< Set the XDMA start*/

#define SADC_TEST_ENABLE()                (SADC->SADC_SET1.bit.CFG_SADC_TST_ADJ = ENABLE)       /**< Enable the SADC test mode*/
#define SADC_TEST_ADJUST_VALUE(para_set)  (SADC->SADC_SET1.bit.CFG_SADC_VAL_TST = para_set)     /**< Set the SADC test mode adjust value*/


void Sadc_Register_Int_Callback(sadc_isr_handler_t sadc_int_callback);
void Sadc_Int_Enable(uint32_t int_mask);
void Sadc_Int_Disable(void);

void Sadc_Channel_Enable(sadc_channel_config_t *config_channel);
void Sadc_Channel_Disable(sadc_config_channel_t ch_sel);

void Sadc_Xdma_Config(uint32_t xdma_start_addr,
                      uint16_t xdma_seg_size,
                      uint16_t xdma_blk_size);

void Sadc_Temperature_Enable(void);

uint32_t Sadc_Init(sadc_config_t *p_config, sadc_isr_handler_t sadc_int_callback);
void Sadc_Enable(void);
void Sadc_Start(void);

uint32_t Sadc_Resolution_Compensation(sadc_value_t *p_data);
sadc_convert_state_t Sadc_Convert_State_Get(void);

#endif /* end of _SADC_H_ */

