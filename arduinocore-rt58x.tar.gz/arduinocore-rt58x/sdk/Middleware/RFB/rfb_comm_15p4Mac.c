/**
 * @file rfb_comm_zigbee.c
 * @author
 * @date
 * @brief Apis for RFB communication subsystem and ruci format
 *
 * More detailed description can go here
 *
 *
 * @see http://
 */
/**************************************************************************************************
*    INCLUDES
*************************************************************************************************/
#include "cm3_mcu.h"
#include "Ruci.h"
#include "rfb_comm_15p4Mac.h"
/**************************************************************************************************
 *    MACROS
 *************************************************************************************************/

/**************************************************************************************************
 *    CONSTANTS AND DEFINES
 *************************************************************************************************/

/**************************************************************************************************
 *    TYPEDEFS
 *************************************************************************************************/

/**************************************************************************************************
 *    GLOBAL VARIABLES
 *************************************************************************************************/

/**************************************************************************************************
 *    LOCAL FUNCTIONS
 *************************************************************************************************/

extern RF_MCU_RX_CMDQ_ERROR rfb_event_read(uint8_t *packet_length, uint8_t *event_address);
extern void enter_critical_section(void);
extern void leave_critical_section(void);
extern void rfb_send_cmd(uint8_t *cmd_address, uint8_t cmd_length);
/**************************************************************************************************
 *    GLOBAL FUNCTIONS
 *************************************************************************************************/
RFB_EVENT_STATUS  rfb_comm_zigbee_initiate(void)
{
    sRUCI_PARA_INITIATE_ZIGBEE sZigbeeInitCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_ZIGBEE_INIT(&sZigbeeInitCmd);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sZigbeeInitCmd, RUCI_INITIATE_ZIGBEE);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sZigbeeInitCmd, RUCI_LEN_INITIATE_ZIGBEE);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_INITIATE_ZIGBEE)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS  rfb_comm_15p4_address_filter_set(uint8_t mac_promiscuous_mode, uint16_t short_source_address, uint32_t long_source_address_0, uint32_t long_source_address_1, uint16_t pan_id, uint8_t is_coordinator)
{
    sRUCI_PARA_SET15P4_ADDRESS_FILTER sAddressFielterSetCmd = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_SET15P4_ADDR_FILTER(&sAddressFielterSetCmd, mac_promiscuous_mode, short_source_address, long_source_address_0,
                                  long_source_address_1, pan_id, is_coordinator);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sAddressFielterSetCmd, RUCI_SET15P4_ADDRESS_FILTER);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sAddressFielterSetCmd, RUCI_LEN_SET15P4_ADDRESS_FILTER);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET15P4_ADDRESS_FILTER)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_15p4_mac_pib_set(uint32_t a_unit_backoff_period, uint32_t mac_ack_wait_duration, uint8_t mac_max_BE, uint8_t mac_max_CSMA_backoffs,
                                   uint32_t mac_max_frame_total_wait_time, uint8_t mac_max_frame_retries, uint8_t mac_min_BE)
{
    sRUCI_PARA_SET15P4_MAC_PIB s15p4Mac = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_SET15P4_MAC_PIB(&s15p4Mac, a_unit_backoff_period, mac_ack_wait_duration, mac_max_BE, mac_max_CSMA_backoffs, mac_max_frame_total_wait_time,
                                  mac_max_frame_retries, mac_min_BE);

    RUCI_ENDIAN_CONVERT((uint8_t *)&s15p4Mac, RUCI_SET15P4_SW_MAC);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&s15p4Mac, RUCI_LEN_SET15P4_MAC_PIB);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET15P4_MAC_PIB)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}

RFB_EVENT_STATUS rfb_comm_15p4_phy_pib_set(uint16_t a_turnaround_time, uint8_t phy_cca_mode, uint8_t phy_cca_threshold, uint16_t phy_cca_duration)
{
    sRUCI_PARA_SET15P4_PHY_PIB s15p4Phy = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_SET15P4_PHY_PIB(&s15p4Phy, a_turnaround_time, phy_cca_mode, phy_cca_threshold, phy_cca_duration);

    RUCI_ENDIAN_CONVERT((uint8_t *)&s15p4Phy, RUCI_SET15P4_PHY_PIB);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&s15p4Phy, RUCI_LEN_SET15P4_PHY_PIB);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET15P4_PHY_PIB)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}


RFB_EVENT_STATUS rfb_comm_15p4_auto_ack_set(uint8_t auto_ack_enable)
{
    sRUCI_PARA_SET15P4_AUTO_ACK sAutoAck = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_SET15P4_AUTO_ACK(&sAutoAck, auto_ack_enable);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sAutoAck, RUCI_SET15P4_AUTO_ACK);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sAutoAck, RUCI_LEN_SET15P4_AUTO_ACK);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET15P4_AUTO_ACK)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}



RFB_EVENT_STATUS rfb_comm_15p4_pending_bit_set(uint8_t pending_bit_enable)
{
    sRUCI_PARA_SET15P4_PENDING_BIT sFramePending = {0};
    sRUCI_PARA_CNF_EVENT sCnfEvent = {0};
    uint8_t event_len = 0;
    RF_MCU_RX_CMDQ_ERROR event_status = RF_MCU_RX_CMDQ_ERR_INIT;

    SET_RUCI_PARA_SET15P4_PENDING_BIT(&sFramePending, pending_bit_enable);

    RUCI_ENDIAN_CONVERT((uint8_t *)&sFramePending, RUCI_SET15P4_PENDING_BIT);

    enter_critical_section();
    rfb_send_cmd((uint8_t *)&sFramePending, RUCI_LEN_SET15P4_PENDING_BIT);
    event_status = rfb_event_read(&event_len, (uint8_t *)&sCnfEvent);
    leave_critical_section();

    RUCI_ENDIAN_CONVERT((uint8_t *)&sCnfEvent, RUCI_CNF_EVENT);
    if (event_status != RF_MCU_RX_CMDQ_GET_SUCCESS)
        return RFB_CNF_EVENT_NOT_AVAILABLE;
    if (sCnfEvent.PciCmdSubheader != RUCI_CODE_SET15P4_PENDING_BIT)
        return RFB_CNF_EVENT_CONTENT_ERROR;
    if (sCnfEvent.Status != RFB_EVENT_SUCCESS)
        return (RFB_EVENT_STATUS)sCnfEvent.Status;

    return RFB_EVENT_SUCCESS;
}
